
All the code is provided as is with quite possibly some bugs still in it. The only requirement is that both the Kingpin Team for CTC and the original CTC writers remain credited in the MOTD.

Thank you.