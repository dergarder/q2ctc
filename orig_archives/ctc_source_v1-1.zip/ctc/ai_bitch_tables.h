mframe_t	bitch_frames_boredA[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
	ai_stand,	  0.000, bitch_talk_think,	// frame 24
	ai_stand,	  0.000, bitch_talk_think,	// frame 25
	ai_stand,	  0.000, bitch_talk_think,	// frame 26
	ai_stand,	  0.000, bitch_talk_think,	// frame 27
	ai_stand,	  0.000, bitch_talk_think,	// frame 28
	ai_stand,	  0.000, bitch_talk_think,	// frame 29
	ai_stand,	  0.000, bitch_talk_think,	// frame 30
	ai_stand,	  0.000, bitch_talk_think,	// frame 31
	ai_stand,	  0.000, bitch_talk_think,	// frame 32
	ai_stand,	  0.000, bitch_talk_think,	// frame 33
	ai_stand,	  0.000, bitch_talk_think,	// frame 34
	ai_stand,	  0.000, bitch_talk_think,	// frame 35
	ai_stand,	  0.000, bitch_talk_think,	// frame 36
	ai_stand,	  0.000, bitch_talk_think,	// frame 37
	ai_stand,	  0.000, bitch_talk_think,	// frame 38
	ai_stand,	  0.000, bitch_talk_think,	// frame 39
	ai_stand,	  0.000, bitch_talk_think,	// frame 40
	ai_stand,	  0.000, bitch_talk_think,	// frame 41
	ai_stand,	  0.000, bitch_talk_think,	// frame 42
	ai_stand,	  0.000, bitch_talk_think,	// frame 43
	ai_stand,	  0.000, bitch_talk_think,	// frame 44
	ai_stand,	  0.000, bitch_talk_think,	// frame 45
	ai_stand,	  0.000, bitch_talk_think,	// frame 46
	ai_stand,	  0.000, bitch_talk_think	// frame 47
};
mmove_t	bitch_move_boredA = {FRAME_boredA_01, FRAME_boredA_48, bitch_frames_boredA, bitch_end_stand};


mframe_t	bitch_frames_leanlook[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
	ai_stand,	  0.000, bitch_talk_think,	// frame 24
	ai_stand,	  0.000, bitch_talk_think,	// frame 25
	ai_stand,	  0.000, bitch_talk_think,	// frame 26
	ai_stand,	  0.000, bitch_talk_think,	// frame 27
	ai_stand,	  0.000, bitch_talk_think,	// frame 28
	ai_stand,	  0.000, bitch_talk_think,	// frame 29
	ai_stand,	  0.000, bitch_talk_think,	// frame 30
	ai_stand,	  0.000, bitch_talk_think,	// frame 31
	ai_stand,	  0.000, bitch_talk_think,	// frame 32
	ai_stand,	  0.000, bitch_talk_think,	// frame 33
	ai_stand,	  0.000, bitch_talk_think,	// frame 34
	ai_stand,	  0.000, bitch_talk_think,	// frame 35
	ai_stand,	  0.000, bitch_talk_think,	// frame 36
	ai_stand,	  0.000, bitch_talk_think,	// frame 37
	ai_stand,	  0.000, bitch_talk_think,	// frame 38
};
mmove_t	bitch_move_leanlook = {FRAME_leanlook_01, FRAME_leanlook_39, bitch_frames_leanlook, bitch_end_stand};

mframe_t	bitch_frames_leanwave[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
	ai_stand,	  0.000, bitch_talk_think,	// frame 24
	ai_stand,	  0.000, bitch_talk_think,	// frame 25
	ai_stand,	  0.000, bitch_talk_think,	// frame 26
	ai_stand,	  0.000, bitch_talk_think,	// frame 27
	ai_stand,	  0.000, bitch_talk_think,	// frame 28
	ai_stand,	  0.000, bitch_talk_think,	// frame 29
	ai_stand,	  0.000, bitch_talk_think,	// frame 30
	ai_stand,	  0.000, bitch_talk_think,	// frame 31
	ai_stand,	  0.000, bitch_talk_think,	// frame 32
};
mmove_t	bitch_move_leanwave = {FRAME_leanwave_01, FRAME_leanwave_33, bitch_frames_leanwave, bitch_end_stand};

mframe_t	bitch_frames_whatsup[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
	ai_stand,	  0.000, bitch_talk_think,	// frame 24
	ai_stand,	  0.000, bitch_talk_think,	// frame 25
	ai_stand,	  0.000, bitch_talk_think,	// frame 26
};
mmove_t	bitch_move_whatsup = {FRAME_whatsup_01, FRAME_whatsup_27, bitch_frames_whatsup, bitch_end_stand};

mframe_t	bitch_frames_talkme[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
};
mmove_t	bitch_move_talkme = {FRAME_talkme_01, FRAME_talkme_20, bitch_frames_talkme, bitch_end_stand};

mframe_t	bitch_frames_nonono[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
	ai_stand,	  0.000, bitch_talk_think,	// frame 24
	ai_stand,	  0.000, bitch_talk_think,	// frame 25
};
mmove_t	bitch_move_nonono = {FRAME_nonono_01, FRAME_nonono_26, bitch_frames_nonono, bitch_end_stand};

mframe_t	bitch_frames_comeon[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
};
mmove_t	bitch_move_comeon = {FRAME_comeon_01, FRAME_comeon_20, bitch_frames_comeon, bitch_end_stand};

mframe_t	bitch_frames_getdown[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
};
mmove_t	bitch_move_getdown = {FRAME_getdown_01, FRAME_getdown_22, bitch_frames_getdown, bitch_end_stand};

mframe_t	bitch_frames_whomw[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
};
mmove_t	bitch_move_whomw = {FRAME_whomw_01, FRAME_whomw_24, bitch_frames_whomw, bitch_end_stand};

mframe_t	bitch_frames_lookself[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
	ai_stand,	  0.000, bitch_talk_think,	// frame 24
	ai_stand,	  0.000, bitch_talk_think,	// frame 25
	ai_stand,	  0.000, bitch_talk_think,	// frame 26
	ai_stand,	  0.000, bitch_talk_think,	// frame 27
	ai_stand,	  0.000, bitch_talk_think,	// frame 28
	ai_stand,	  0.000, bitch_talk_think,	// frame 29
	ai_stand,	  0.000, bitch_talk_think,	// frame 30
	ai_stand,	  0.000, bitch_talk_think,	// frame 31
	ai_stand,	  0.000, bitch_talk_think,	// frame 32
	ai_stand,	  0.000, bitch_talk_think,	// frame 33
};
mmove_t	bitch_move_lookself = {FRAME_lookself_01, FRAME_lookself_34, bitch_frames_lookself, bitch_end_stand};

mframe_t	bitch_frames_flirt[] = 
{
	ai_stand,	  0.000, bitch_talk_think,	// frame 0
	ai_stand,	  0.000, bitch_talk_think,	// frame 1
	ai_stand,	  0.000, bitch_talk_think,	// frame 2
	ai_stand,	  0.000, bitch_talk_think,	// frame 3
	ai_stand,	  0.000, bitch_talk_think,	// frame 4
	ai_stand,	  0.000, bitch_talk_think,	// frame 5
	ai_stand,	  0.000, bitch_talk_think,	// frame 6
	ai_stand,	  0.000, bitch_talk_think,	// frame 7
	ai_stand,	  0.000, bitch_talk_think,	// frame 8
	ai_stand,	  0.000, bitch_talk_think,	// frame 9
	ai_stand,	  0.000, bitch_talk_think,	// frame 10
	ai_stand,	  0.000, bitch_talk_think,	// frame 11
	ai_stand,	  0.000, bitch_talk_think,	// frame 12
	ai_stand,	  0.000, bitch_talk_think,	// frame 13
	ai_stand,	  0.000, bitch_talk_think,	// frame 14
	ai_stand,	  0.000, bitch_talk_think,	// frame 15
	ai_stand,	  0.000, bitch_talk_think,	// frame 16
	ai_stand,	  0.000, bitch_talk_think,	// frame 17
	ai_stand,	  0.000, bitch_talk_think,	// frame 18
	ai_stand,	  0.000, bitch_talk_think,	// frame 19
	ai_stand,	  0.000, bitch_talk_think,	// frame 20
	ai_stand,	  0.000, bitch_talk_think,	// frame 21
	ai_stand,	  0.000, bitch_talk_think,	// frame 22
	ai_stand,	  0.000, bitch_talk_think,	// frame 23
	ai_stand,	  0.000, bitch_talk_think,	// frame 24
	ai_stand,	  0.000, bitch_talk_think,	// frame 25
	ai_stand,	  0.000, bitch_talk_think,	// frame 26
	ai_stand,	  0.000, bitch_talk_think,	// frame 27
	ai_stand,	  0.000, bitch_talk_think,	// frame 28
	ai_stand,	  0.000, bitch_talk_think,	// frame 29
	ai_stand,	  0.000, bitch_talk_think,	// frame 30
	ai_stand,	  0.000, bitch_talk_think,	// frame 31
	ai_stand,	  0.000, bitch_talk_think,	// frame 32
};
mmove_t	bitch_move_flirt = {FRAME_flirt_01, FRAME_flirt_33, bitch_frames_flirt, bitch_end_stand};

mframe_t	bitch_frames_walk_shoot[] = 
{
	ai_charge,-0.387, NULL,	// frame 0
	ai_charge,14.335, NULL,	// frame 1
	ai_charge, 3.746, bitch_right_fire,	// frame 2
	ai_charge,-2.939, NULL,	// frame 3
	ai_charge,12.968, NULL,	// frame 4
	ai_charge, 8.805, NULL,	// frame 5
	ai_charge, 5.401, bitch_right_fire,	// frame 6
	ai_charge, 3.617, NULL,	// frame 7
	ai_charge, 7.752, NULL,	// frame 8
	ai_charge, 5.046, NULL,	// frame 9
	ai_charge, 7.724, bitch_right_fire,	// frame 10

};
mmove_t	bitch_move_walk_shoot = {FRAME_walk_shoot_01, FRAME_walk_shoot_11, bitch_frames_walk_shoot, AI_EndAttack};

mframe_t	bitch_frames_walk_guns_dn[] = 
{
	ai_run,	  15.394, NULL,	// frame 0
	ai_run,	  12.447, NULL,	// frame 1
	ai_run,	   7.060, NULL,	// frame 2
	ai_run,	   1.269, NULL,	// frame 3
	ai_run,	  -0.079, NULL,	// frame 4
	ai_run,	   2.024, NULL,	// frame 5
	ai_run,	   5.744, NULL,	// frame 6
	ai_run,	   6.065, NULL,	// frame 7
	ai_run,	   3.934, NULL,	// frame 8
	ai_run,	   6.049, NULL,	// frame 9
	ai_run,	   5.951, NULL,	// frame 10

};
mmove_t	bitch_move_walk_guns_dn = {FRAME_walk_guns_dn_01, FRAME_walk_guns_dn_11, bitch_frames_walk_guns_dn, NULL};

mframe_t	bitch_frames_run_shoot[] = 
{
	ai_charge,	 25.544, bitch_right_fire,	// frame 0
	ai_charge,	 16.408, NULL,	// frame 1
	ai_charge,	 11.801, NULL,	// frame 2
	ai_charge,	 22.815, bitch_right_fire,	// frame 3
	ai_charge,	 19.555, NULL,	// frame 4
	ai_charge,	 13.387, NULL,	// frame 5
	ai_charge,	 23.020, bitch_right_fire,	// frame 6
};
mmove_t	bitch_move_run_shoot = {FRAME_run_shoot_01, FRAME_run_shoot_07, bitch_frames_run_shoot, AI_EndAttack};

mframe_t	bitch_frames_reverse_run_shoot[] = 
{
	ai_charge,-  23.020, bitch_right_fire,	// frame 6
	ai_charge,-	 13.387, NULL,	// frame 5
	ai_charge,-	 19.555, NULL,	// frame 4
	ai_charge,-	 22.815, bitch_right_fire,	// frame 3
	ai_charge,-	 11.801, NULL,	// frame 2
	ai_charge,-	 16.408, NULL,	// frame 1
	ai_charge,-	 25.544, bitch_right_fire,	// frame 0
};
mmove_t	bitch_move_reverse_run_shoot = {FRAME_run_shoot_07, FRAME_run_shoot_01, bitch_frames_reverse_run_shoot, AI_EndAttack};

mframe_t	bitch_frames_run_guns_dn[] = 
{
	ai_run,	 17.697, NULL,	// frame 0
	ai_run,	 15.930, NULL,	// frame 1
	ai_run,	 15.610, NULL,	// frame 2
	ai_run,	 18.980, NULL,	// frame 3
	ai_run,	 21.142, NULL,	// frame 4
	ai_run,	 15.510, NULL,	// frame 5
	ai_run,	 20.503, NULL,	// frame 6
};
mmove_t	bitch_move_run_guns_dn = {FRAME_run_guns_dn_01, FRAME_run_guns_dn_07, bitch_frames_run_guns_dn, NULL};

mframe_t	bitch_frames_lside_run[] = 
{
	ai_sidestep, - 5.667, bitch_firegun_left,	// frame 0
	ai_sidestep, -17.557, NULL,	// frame 1
	ai_sidestep, -18.095, NULL,	// frame 2
	ai_sidestep, -16.412, bitch_firegun_left,	// frame 3
	ai_sidestep, -19.351, NULL,	// frame 4
	ai_sidestep, -19.924, NULL,	// frame 5
	ai_sidestep, -15.967, bitch_firegun_left	// frame 6
};
mmove_t	bitch_move_lside_run = {FRAME_lside_run_01, FRAME_lside_run_07, bitch_frames_lside_run, NULL};

mframe_t	bitch_frames_rside_run[] = 
{
	ai_sidestep,  5.422, bitch_firegun_right,	// frame 0
	ai_sidestep, 17.349, NULL,	// frame 1
	ai_sidestep, 15.397, NULL,	// frame 2
	ai_sidestep, 19.357, bitch_firegun_right,	// frame 3
	ai_sidestep, 19.243, NULL,	// frame 4
	ai_sidestep, 16.958, NULL,	// frame 5
	ai_sidestep, 19.244, bitch_firegun_right	// frame 6
};
mmove_t	bitch_move_rside_run = {FRAME_rside_run_01, FRAME_rside_run_07, bitch_frames_rside_run, NULL};

mframe_t	bitch_frames_run_on_fire[] = 
{

	ai_onfire_run,	 6.564 , NULL,	// frame 0
	ai_onfire_run,	20.491 , NULL,	// frame 1
	ai_onfire_run,	13.021 , NULL,	// frame 2
	ai_onfire_run,	26.721 , NULL,	// frame 3
	ai_onfire_run,	17.332 , NULL,	// frame 4
	ai_onfire_run,	11.295 , NULL,	// frame 5
	ai_onfire_run,	17.608 , NULL,	// frame 6
	ai_onfire_run,	18.820 , NULL,	// frame 7
	ai_onfire_run,	17.630 , NULL,	// frame 8
	ai_onfire_run,	18.087 , NULL,	// frame 9
	ai_onfire_run,	23.520 , NULL,	// frame 10
	ai_onfire_run,	12.192 , NULL,	// frame 11
	ai_onfire_run,	20.855 , NULL,	// frame 12

};
mmove_t	bitch_move_run_on_fire = {FRAME_run_on_fire_01, FRAME_run_on_fire_13, bitch_frames_run_on_fire, NULL};

mframe_t	bitch_frames_evd_walk[] = 
{
	ai_turn,	-3.523 , NULL,	// frame 0
	ai_turn,	-7.377 , NULL,	// frame 1
	ai_turn,	-5.952 , NULL,	// frame 2
	ai_turn,	-9.002 , NULL,	// frame 3
	ai_turn,	-8.051 , NULL,	// frame 4
	ai_turn,	-1.897 , NULL,	// frame 5
	ai_turn,	-1.948 , NULL,	// frame 6
};
mmove_t	bitch_move_evd_walk = {FRAME_evd_walk_01, FRAME_evd_walk_07, bitch_frames_evd_walk, bitch_evade_amb};


mframe_t	bitch_frames_evade_adjust[] = 
{
	ai_turn,  -9.002, bitch_evade_adjust,	// frame 4
	ai_turn,  -8.051, bitch_evade_adjust,	// frame 5
	ai_turn,  -1.897, bitch_evade_adjust,	// frame 6
	ai_turn,  -1.948, bitch_evade_adjust,	// frame 7
};
mmove_t	bitch_move_evade_adjust = {FRAME_evd_walk_04, FRAME_evd_walk_07, bitch_frames_evade_adjust, bitch_evade_amb};


mframe_t	bitch_frames_evd_amb[] = 
{
	ai_turn,	 0.0, NULL,	// frame 0
	ai_turn,	 0.0, NULL,	// frame 1
	ai_turn,	 0.0, NULL,	// frame 2
	ai_turn,	 0.0, NULL,	// frame 3
	ai_turn,	 0.0, NULL,	// frame 4
	ai_turn,	 0.0, NULL,	// frame 5
	ai_turn,	 0.0, NULL,	// frame 6
	ai_turn,	 0.0, NULL,	// frame 7
	ai_turn,	 0.0, NULL,	// frame 8
	ai_turn,	 0.0, NULL,	// frame 9
	ai_turn,	 0.0, NULL,	// frame 10
};
mmove_t	bitch_move_evd_amb = {FRAME_evd_amb_01, FRAME_evd_amb_11, bitch_frames_evd_amb, AI_CheckEvade};


mframe_t	bitch_frames_evd_stand[] = 
{
	ai_stand,	 0.0, NULL,	// frame 0
	ai_stand,	 0.0, NULL,	// frame 1
	ai_stand,	 0.0, NULL,	// frame 2
	ai_stand,	 0.0, NULL,	// frame 3
	ai_stand,	 0.0, NULL,	// frame 4
	ai_stand,	 0.0, NULL,	// frame 5
	ai_stand,	 0.0, NULL,	// frame 6
	ai_stand,	 0.0, NULL,	// frame 7
	ai_stand,	 0.0, NULL,	// frame 8
	ai_stand,	 0.0, NULL,	// frame 9
	ai_stand,	 0.0, NULL,	// frame 10
};
mmove_t	bitch_move_evd_stand = {FRAME_evd_amb_01, FRAME_evd_amb_11, bitch_frames_evd_stand, bitch_end_stand};


mframe_t	bitch_frames_pull_gun[] = 
{
	ai_charge,	  0.000, NULL,	// frame 0
	ai_charge,	  0.000, NULL,	// frame 1
	ai_charge,	  0.000, bitch_show_guns,	// frame 2
	ai_charge,	  0.000, NULL,	// frame 3
	ai_charge,	  0.000, NULL,	// frame 4
	ai_charge,	  0.000, NULL,	// frame 5
	ai_charge,	  0.000, NULL,	// frame 6
	ai_charge,	  0.000, NULL,	// frame 7
};
mmove_t	bitch_move_pull_gun = {FRAME_pull_gun_01, FRAME_pull_gun_08, bitch_frames_pull_gun, AI_EndAttack};

mframe_t	bitch_frames_shoot_stand[] = 
{
	ai_charge,	  0.000, bitch_right_fire,	// frame 0
	ai_charge,	  0.000, NULL,	// frame 1
	ai_charge,	  0.000, bitch_right_fire,	// frame 2
	ai_charge,	  0.000, NULL,	// frame 3
	ai_charge,	  0.000, bitch_right_fire,	// frame 4
};
mmove_t	bitch_move_shoot_stand = {FRAME_stand_shoot_01, FRAME_stand_shoot_05, bitch_frames_shoot_stand, AI_EndAttack};

mframe_t	bitch_frames_reload[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
	NULL,	  0.000, NULL,	// frame 9
	NULL,	  0.000, NULL,	// frame 10
	NULL,	  0.000, NULL,	// frame 11
	NULL,	  0.000, NULL,	// frame 12
	NULL,	  0.000, NULL,	// frame 13
	NULL,	  0.000, NULL,	// frame 14
	NULL,	  0.000, NULL,	// frame 15
	NULL,	  0.000, NULL,	// frame 16
	NULL,	  0.000, NULL,	// frame 17
	NULL,	  0.000, NULL,	// frame 18
	NULL,	  0.000, NULL,	// frame 19
};
mmove_t	bitch_move_reload = {FRAME_reload_01, FRAME_reload_13, bitch_frames_reload, AI_EndAttack};



mframe_t	bitch_frames_p_pain_chst[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
};
mmove_t	bitch_move_p_pain_chst = {FRAME_p_pain_chst_01, FRAME_p_pain_chst_06, bitch_frames_p_pain_chst, AI_EndAttack};

mframe_t	bitch_frames_p_pain_rshd[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
};
mmove_t	bitch_move_p_pain_rshd = {FRAME_p_pain_rshd_01, FRAME_p_pain_rshd_07, bitch_frames_p_pain_rshd, AI_EndAttack};

mframe_t	bitch_frames_p_pain_lshd[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
};
mmove_t	bitch_move_p_pain_lshd = {FRAME_p_pain_lshd_01, FRAME_p_pain_lshd_06, bitch_frames_p_pain_lshd, AI_EndAttack};

mframe_t	bitch_frames_p_pain_rshd2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
};
mmove_t	bitch_move_p_pain_rshd2 = {FRAME_p_pain_rshd2_01, FRAME_p_pain_rshd2_05, bitch_frames_p_pain_rshd2, AI_EndAttack};

mframe_t	bitch_frames_p_pain_rleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
};
mmove_t	bitch_move_p_pain_rleg = {FRAME_p_pain_rleg_01, FRAME_p_pain_rleg_08, bitch_frames_p_pain_rleg, AI_EndAttack};

mframe_t	bitch_frames_p_pain_lleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
};
mmove_t	bitch_move_p_pain_lleg = {FRAME_p_pain_lleg_01, FRAME_p_pain_lleg_07, bitch_frames_p_pain_lleg, AI_EndAttack};

mframe_t	bitch_frames_p_pain_crch[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
};
mmove_t	bitch_move_p_pain_crch = {FRAME_p_pain_crch_01, FRAME_p_pain_crch_07, bitch_frames_p_pain_crch, AI_EndAttack};

mframe_t	bitch_frames_p_pain_butt[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
	ai_move,	  0.000, NULL,	// frame 11
	ai_move,	  0.000, NULL,	// frame 12
};
mmove_t	bitch_move_p_pain_butt = {FRAME_p_pain_butt_01, FRAME_p_pain_butt_13, bitch_frames_p_pain_butt, AI_EndAttack};

mframe_t	bitch_frames_p_pain_lshd2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	bitch_move_p_pain_lshd2 = {FRAME_p_pain_lshd2_01, FRAME_p_pain_lshd2_09, bitch_frames_p_pain_lshd2, AI_EndAttack};

mframe_t	bitch_frames_p_pain_rleg2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
};
mmove_t	bitch_move_p_pain_rleg2 = {FRAME_p_pain_rleg2_01, FRAME_p_pain_rleg2_10, bitch_frames_p_pain_rleg2, AI_EndAttack};

mframe_t	bitch_frames_p_pain_lleg2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
};
mmove_t	bitch_move_p_pain_lleg2 = {FRAME_p_pain_lleg2_01, FRAME_p_pain_lleg2_07, bitch_frames_p_pain_lleg2, AI_EndAttack};

mframe_t	bitch_frames_p_pain_crch2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
};
mmove_t	bitch_move_p_pain_crch2 = {FRAME_p_pain_crch2_01, FRAME_p_pain_crch2_06, bitch_frames_p_pain_crch2, AI_EndAttack};

mframe_t	bitch_frames_p_pain_butt2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
};
mmove_t	bitch_move_p_pain_butt2 = {FRAME_p_pain_butt2_01, FRAME_p_pain_butt2_08, bitch_frames_p_pain_butt2, AI_EndAttack};

mframe_t	bitch_frames_p_pain_head2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
};
mmove_t	bitch_move_p_pain_head2 = {FRAME_p_pain_head2_01, FRAME_p_pain_head2_04, bitch_frames_p_pain_head2, AI_EndAttack};


mframe_t	bitch_frames_death1[] = 
{
	ai_move,	 -6.175, NULL,	// frame 0
	ai_move,	 -3.499, NULL,	// frame 1
	ai_move,	 -6.851, NULL,	// frame 2
	ai_move,	-12.644, NULL,	// frame 3
	ai_move,	-22.505, NULL,	// frame 4
	ai_move,	  1.774, NULL,	// frame 5
	ai_move,	 -5.915, NULL,	// frame 6
	ai_move,	 -0.512, NULL,	// frame 7
	ai_move,	  1.367, NULL,	// frame 8
	ai_move,	  1.460, NULL,	// frame 9
	ai_move,	  0.932, NULL,	// frame 10
	ai_move,	 -0.798, NULL,	// frame 11
	ai_move,	 -1.688, NULL,	// frame 12
	ai_move,	 -0.359, NULL,	// frame 13
	ai_move,	 -0.033, NULL,	// frame 14

};
mmove_t	bitch_move_death1 = {FRAME_death1_01, FRAME_death1_15, bitch_frames_death1, AI_EndDeath};

mframe_t	bitch_frames_death2[] = 
{
	ai_move,	 -4.503, NULL,	// frame 0
	ai_move,	 -6.637, NULL,	// frame 1
	ai_move,	 -7.037, NULL,	// frame 2
	ai_move,	-15.226, NULL,	// frame 3
	ai_move,	-10.693, NULL,	// frame 4
	ai_move,	 -7.248, NULL,	// frame 5
	ai_move,	 -6.418, NULL,	// frame 6
	ai_move,	 -3.067, NULL,	// frame 7
	ai_move,	 -0.148, NULL,	// frame 8
	ai_move,	 -1.794, NULL,	// frame 9
	ai_move,	 -1.262, NULL,	// frame 10
	ai_move,	  0.233, NULL,	// frame 11
	ai_move,	  0.098, NULL,	// frame 12
	ai_move,	 -0.047, NULL,	// frame 13
	ai_move,	 -0.051, NULL,	// frame 14
	ai_move,	  0.024, NULL,	// frame 15
};
mmove_t	bitch_move_death2 = {FRAME_death2_01, FRAME_death2_16, bitch_frames_death2, AI_EndDeath};

mframe_t	bitch_frames_death3[] = 
{
	ai_move,	 -2.798, NULL,	// frame 0
	ai_move,	  9.722, NULL,	// frame 1
	ai_move,	  8.203, NULL,	// frame 2
	ai_move,	  6.324, NULL,	// frame 3
	ai_move,	  8.530, NULL,	// frame 4
	ai_move,	  9.302, NULL,	// frame 5
	ai_move,	  2.073, NULL,	// frame 6
	ai_move,	  0.491, NULL,	// frame 7
	ai_move,	 -0.245, NULL,	// frame 8
	ai_move,	  0.103, NULL,	// frame 9
	ai_move,	  0.026, NULL,	// frame 10
	ai_move,	 -0.040, NULL,	// frame 11
	ai_move,	 -0.005, NULL,	// frame 12
	ai_move,	  0.017, NULL,	// frame 13
	ai_move,	 -0.007, NULL,	// frame 14
	ai_move,	 -0.001, NULL,	// frame 15
};
mmove_t	bitch_move_death3 = {FRAME_death3_01, FRAME_death3_16, bitch_frames_death3, AI_EndDeath};

mframe_t	bitch_frames_death4[] = 
{
	ai_move,	 -1.635, NULL,	// frame 0
	ai_move,	  0.821, NULL,	// frame 1
	ai_move,	  1.613, NULL,	// frame 2
	ai_move,	  2.872, NULL,	// frame 3
	ai_move,	  2.480, NULL,	// frame 4
	ai_move,	  3.158, NULL,	// frame 5
	ai_move,	  5.585, NULL,	// frame 6
	ai_move,	  3.709, NULL,	// frame 7
	ai_move,	 -0.516, NULL,	// frame 8
	ai_move,	 -1.012, NULL,	// frame 9
	ai_move,	 -1.925, NULL,	// frame 10
	ai_move,	  3.284, NULL,	// frame 11
	ai_move,	  6.448, NULL,	// frame 12
	ai_move,	  6.095, NULL,	// frame 13
	ai_move,	  5.101, NULL,	// frame 14
	ai_move,	  0.425, NULL,	// frame 15
	ai_move,	  0.241, NULL,	// frame 16
	ai_move,	  1.507, NULL,	// frame 17
	ai_move,	  0.167, NULL,	// frame 18
	ai_move,	 -0.324, NULL,	// frame 19
	ai_move,	 -0.151, NULL,	// frame 20
	ai_move,	  0.024, NULL,	// frame 21
};
mmove_t	bitch_move_death4 = {FRAME_death4_01, FRAME_death4_22, bitch_frames_death4, AI_EndDeath};

mframe_t	bitch_frames_death5[] = 
{
	ai_move,	 -2.966, NULL,	// frame 0
	ai_move,	  4.526, NULL,	// frame 1
	ai_move,	  3.461, NULL,	// frame 2
	ai_move,	  0.109, NULL,	// frame 3
	ai_move,	  2.338, NULL,	// frame 4
	ai_move,	  3.914, NULL,	// frame 5
	ai_move,	  4.384, NULL,	// frame 6
	ai_move,	  1.872, NULL,	// frame 7
	ai_move,	 -0.987, NULL,	// frame 8
	ai_move,	  0.239, NULL,	// frame 9
	ai_move,	 -0.840, NULL,	// frame 10
	ai_move,	 -0.444, NULL,	// frame 11
	ai_move,	  0.330, NULL,	// frame 12
	ai_move,	  0.396, NULL,	// frame 13
	ai_move,	  0.506, NULL,	// frame 14
	ai_move,	  1.860, NULL,	// frame 15
	ai_move,	  4.885, NULL,	// frame 16
	ai_move,	 11.843, NULL,	// frame 17
	ai_move,	  2.474, NULL,	// frame 18
	ai_move,	 -2.247, NULL,	// frame 19
	ai_move,	 -1.171, NULL,	// frame 20
	ai_move,	  0.513, NULL,	// frame 21
	ai_move,	 -0.415, NULL,	// frame 22
	ai_move,	 -0.085, NULL,	// frame 23
	ai_move,	  0.103, NULL,	// frame 24
	ai_move,	  0.042, NULL,	// frame 25
	ai_move,	  0.006, NULL,	// frame 26
	ai_move,	  0.004, NULL,	// frame 27
	ai_move,	  0.002, NULL,	// frame 28
	ai_move,	  0.011, NULL,	// frame 29
	ai_move,	  0.000, NULL,	// frame 30
	ai_move,	  0.002, NULL,	// frame 31
	ai_move,	 -0.002, NULL,	// frame 32
};
mmove_t	bitch_move_death5 = {FRAME_death5_01, FRAME_death5_33, bitch_frames_death5, AI_EndDeath};







// custom moves

mframe_t	bitch_frames_avoid_walk[] = 
{
	ai_turn,	  2.385, NULL,	// frame 0
	ai_turn,	 11.490, NULL,	// frame 1
	ai_turn,	  6.246, NULL,	// frame 2
	ai_turn,	 -0.401, NULL,	// frame 3
	ai_turn,	  0.363, NULL,	// frame 4
	ai_turn,	  7.448, NULL,	// frame 5
	ai_turn,	  8.381, NULL,	// frame 6
	ai_turn,	  8.323, NULL,	// frame 7
	ai_turn,	  1.809, NULL,	// frame 8
	ai_turn,	  1.921, NULL,	// frame 9
	ai_turn,	  8.302, NULL,	// frame 10

};
mmove_t	bitch_move_avoid_walk = {FRAME_walk_guns_dn_01, FRAME_walk_guns_dn_11, bitch_frames_avoid_walk, AI_EndAttack};
// ok


mframe_t	bitch_frames_avoid_reverse_walk[] = 
{
	ai_turn,	  -8.302, NULL,	// frame 10
	ai_turn,	  -1.921, NULL,	// frame 9
	ai_turn,	  -1.809, NULL,	// frame 8
	ai_turn,	  -8.323, NULL,	// frame 7
	ai_turn,	  -8.381, NULL,	// frame 6
	ai_turn,	  -7.448, NULL,	// frame 5
	ai_turn,	  -0.363, NULL,	// frame 4
	ai_turn,	 0.401, NULL,	// frame 3
	ai_turn,	 -6.246, NULL,	// frame 2
	ai_turn,	 -11.490, NULL,	// frame 1
	ai_turn,	 -2.385, NULL,	// frame 0
};
mmove_t	bitch_move_avoid_reverse_walk = {FRAME_walk_guns_dn_11, FRAME_walk_guns_dn_01, bitch_frames_avoid_reverse_walk, AI_EndAttack};
// ok


mframe_t	bitch4_frames_crch_avoid_walk[] = 
{
	ai_turn,	  3.161, NULL,	// frame 0
	ai_turn,	  5.625, NULL,	// frame 1
	ai_turn,	  6.073, NULL,	// frame 2
	ai_turn,	  4.260, NULL,	// frame 3
	ai_turn,	  3.528, NULL,	// frame 4
	ai_turn,	  5.728, NULL,	// frame 5
	ai_turn,	  9.076, NULL,	// frame 6
};
mmove_t	bitch_move_crch_avoid_walk = {FRAME_crch_walk_01, FRAME_crch_walk_07, bitch4_frames_crch_avoid_walk, AI_EndAttack};



mframe_t	bitch_frames_avoid_run[] = 
{
	ai_turn,	 15.508, NULL,	// frame 0
	ai_turn,	 15.090, NULL,	// frame 1
	ai_turn,	 14.876, NULL,	// frame 2
	ai_turn,	 20.541, NULL,	// frame 3
	ai_turn,	 21.397, NULL,	// frame 4
	ai_turn,	 13.534, NULL,	// frame 5
	ai_turn,	 22.275, NULL,	// frame 6
};
mmove_t	bitch_move_avoid_run = {FRAME_run_guns_dn_01, FRAME_run_guns_dn_07, bitch_frames_avoid_run, AI_EndAttack};
// ok


mframe_t	bitch_frames_avoid_reverse_run[] = 
{
	ai_turn,	 22.275, NULL,	// frame 6
	ai_turn,	 13.534, NULL,	// frame 5
	ai_turn,	 21.397, NULL,	// frame 4
	ai_turn,	 20.541, NULL,	// frame 3
	ai_turn,	 14.876, NULL,	// frame 2
	ai_turn,	 15.090, NULL,	// frame 1
	ai_turn,	 15.508, NULL,	// frame 0
};
mmove_t	bitch_move_avoid_reverse_run = {FRAME_run_guns_dn_07, FRAME_run_guns_dn_01, bitch_frames_avoid_reverse_run, AI_EndAttack};





// new moves

mframe_t	bitch4_frames_stnd2melee[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
};
mmove_t	bitch4_move_stnd2melee = {FRAME_stnd2melee_01, FRAME_stnd2melee_04, bitch4_frames_stnd2melee, NULL};

mframe_t	bitch4_frames_melee2stnd[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
};
mmove_t	bitch4_move_melee2stnd = {FRAME_melee2stnd_01, FRAME_melee2stnd_05, bitch4_frames_melee2stnd, NULL};

mframe_t	bitch4_frames_melee_amb[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
};
mmove_t	bitch4_move_melee_amb = {FRAME_melee_amb_01, FRAME_melee_amb_08, bitch4_frames_melee_amb, NULL};

mframe_t	bitch4_frames_low_melee1[] = 
{
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 0
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 1
	ai_turn2,	  0.000, bitch_melee,	// frame 2
	ai_turn2,	  0.000, NULL,	// frame 3
	ai_turn2,	  0.000, NULL,	// frame 4
	ai_turn2,	  0.000, NULL,	// frame 5
};
mmove_t	bitch4_move_low_melee1 = {FRAME_low_melee1_01, FRAME_low_melee1_06, bitch4_frames_low_melee1, AI_EndAttack};

mframe_t	bitch4_frames_melee1[] = 
{
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 0
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 1
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 2
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 3
	ai_turn2,	  0.000, bitch_melee,	// frame 4
	ai_turn2,	  0.000, NULL,	// frame 5
	ai_turn2,	  0.000, NULL,	// frame 6
	ai_turn2,	  0.000, NULL,	// frame 7

	// the animation is fucked beyond this point
	/*
	ai_turn2,	  0.000, NULL,	// frame 8
	ai_turn2,	  0.000, NULL,	// frame 9
	ai_turn2,	  0.000, NULL,	// frame 10
	ai_turn2,	  0.000, NULL,	// frame 11
	ai_turn2,	  0.000, NULL,	// frame 12
	ai_turn2,	  0.000, NULL,	// frame 13
	ai_turn2,	  0.000, NULL,	// frame 14
	ai_turn2,	  0.000, NULL,	// frame 15
	ai_turn2,	  0.000, NULL,	// frame 16
	ai_turn2,	  0.000, NULL,	// frame 17
	*/
};
mmove_t	bitch4_move_melee1 = {FRAME_melee1_01, FRAME_melee1_08, bitch4_frames_melee1, AI_EndAttack};

/*
This entire animation is messed up the pipe clips her head
mframe_t	bitch4_frames_melee2[] = 
{
	ai_turn2,	  0.000, NULL,	// frame 0
	ai_turn2,	  0.000, NULL,	// frame 1
	ai_turn2,	  0.000, NULL,	// frame 2
	ai_turn2,	  0.000, NULL,	// frame 3
	ai_turn2,	  0.000, NULL,	// frame 4
	ai_turn2,	  0.000, NULL,	// frame 5
	ai_turn2,	  0.000, NULL,	// frame 6
	ai_turn2,	  0.000, NULL,	// frame 7
	ai_turn2,	  0.000, NULL,	// frame 8
	ai_turn2,	  0.000, NULL,	// frame 9
};
mmove_t	bitch4_move_melee2 = {FRAME_melee2_01, FRAME_melee2_10, bitch4_frames_melee2, AI_EndAttack};
*/

mframe_t	bitch4_frames_melee3[] = 
{
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 0
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 1
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 2
	ai_turn2,	  0.000, bitch_melee_bail,	// frame 3
	ai_turn2,	  0.000, bitch_melee,	// frame 4
	ai_turn2,	  0.000, NULL,	// frame 5
	ai_turn2,	  0.000, NULL,	// frame 6
	ai_turn2,	  0.000, NULL,	// frame 7
	// the animation is fucked beyond this point
	/*
	ai_turn2,	  0.000, NULL,	// frame 8
	ai_turn2,	  0.000, NULL,	// frame 9
	ai_turn2,	  0.000, NULL,	// frame 10
	ai_turn2,	  0.000, NULL,	// frame 11
	ai_turn2,	  0.000, NULL,	// frame 12
	ai_turn2,	  0.000, NULL,	// frame 13
	ai_turn2,	  0.000, NULL,	// frame 14
	ai_turn2,	  0.000, NULL,	// frame 15
	ai_turn2,	  0.000, NULL,	// frame 16
	ai_turn2,	  0.000, NULL,	// frame 17
	*/
};
mmove_t	bitch4_move_melee3 = {FRAME_melee3_01, FRAME_melee3_08, bitch4_frames_melee3, AI_EndAttack};

mframe_t	bitch4_frames_run_melee[] = 
{
	ai_charge,	 10.665, NULL,	// frame 0	//Ridah, changed this so it always moves (was negative value)
	ai_charge,	 14.615, NULL,	// frame 1
	ai_charge,	 16.697, NULL,	// frame 2
	ai_charge,	 18.682, bitch_melee,	// frame 3
	ai_charge,	 20.176, NULL,	// frame 4
	ai_charge,	 16.733, NULL,	// frame 5
	ai_charge,	 20.605, NULL,	// frame 6
};
mmove_t	bitch4_move_run_melee = {FRAME_run_melee_01, FRAME_run_melee_07, bitch4_frames_run_melee, AI_EndAttack};

mframe_t	bitch4_frames_jump[] = 
{
//	NULL,	  0.000, NULL,	// frame 0
//	NULL,	  0.000, NULL,	// frame 1
//	NULL,	  0.000, NULL,	// frame 2
//	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, AI_CheckStillInair,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
//	NULL,	  0.000, NULL,	// frame 9
};
mmove_t	bitch4_move_jump = {FRAME_jump_05, FRAME_jump_09, bitch4_frames_jump, AI_EndJump};

mframe_t	bitch4_frames_lside_step[] = 
{
	ai_sidestep, 0.354, NULL,	// frame 0
	ai_sidestep, 1.416, NULL,	// frame 1
	ai_sidestep, 8.838, NULL,	// frame 2
	ai_sidestep, 6.317, NULL,	// frame 3
	ai_sidestep, 6.272, NULL,	// frame 4
	ai_sidestep, 1.312, NULL,	// frame 5
};
mmove_t	bitch4_move_lside_step = {FRAME_lside_step_01, FRAME_lside_step_06, bitch4_frames_lside_step, AI_EndAttack};

mframe_t	bitch4_frames_rside_step[] = 
{
	ai_sidestep, -3.238, NULL,	// frame 0
	ai_sidestep,-11.204, NULL,	// frame 1
	ai_sidestep, -6.360, NULL,	// frame 2
	ai_sidestep, -5.556, NULL,	// frame 3
};
mmove_t	bitch4_move_rside_step = {FRAME_rside_step_01, FRAME_rside_step_04, bitch4_frames_rside_step, AI_EndAttack};


mframe_t	bitch4_frames_st_climb[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
};
mmove_t	bitch4_move_st_climb = {FRAME_st_climb_01, FRAME_st_climb_08, bitch4_frames_st_climb, NULL};

mframe_t	bitch4_frames_clmb_loop[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
	NULL,	  0.000, NULL,	// frame 9
	NULL,	  0.000, NULL,	// frame 10
};
mmove_t	bitch4_move_clmb_loop = {FRAME_clmb_loop_01, FRAME_clmb_loop_11, bitch4_frames_clmb_loop, AI_CheckStillClimbingLadder};

/*
	move does not exist will use this till then
*/

mframe_t	bitch4_frames_clmb_jump[] = 
{
//	NULL,	  0.000, NULL,	// frame 0
//	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, AI_CheckStillInair,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
//	NULL,	  0.000, NULL,	// frame 6
//	NULL,	  0.000, NULL,	// frame 7
};
mmove_t	bitch4_move_clmb_jmp  = {FRAME_st_climb_03, FRAME_st_climb_06, bitch4_frames_clmb_jump, AI_EndJump};

mframe_t	bitch4_frames_crch_dth1[] = 
{
	ai_move,	 -6.696, NULL,	// frame 0
	ai_move,	 -4.322, NULL,	// frame 1
	ai_move,	-12.365, NULL,	// frame 2
	ai_move,	-13.342, NULL,	// frame 3
	ai_move,	 -9.794, NULL,	// frame 4
	ai_move,	-13.628, NULL,	// frame 5
	ai_move,	 -9.628, NULL,	// frame 6
	ai_move,	  0.269, NULL,	// frame 7
	ai_move,	  2.220, NULL,	// frame 8
	ai_move,	  0.794, NULL,	// frame 9
	ai_move,	 -0.188, NULL,	// frame 10
	ai_move,	 -0.880, NULL,	// frame 11
	ai_move,	 -0.311, NULL,	// frame 12
	ai_move,	 -0.042, NULL,	// frame 13
	ai_move,	  0.053, NULL,	// frame 14
	ai_move,	 -0.055, NULL,	// frame 15
	ai_move,	 -0.052, NULL,	// frame 16
	ai_move,	 -0.041, NULL,	// frame 17
};
mmove_t	bitch4_move_crch_dth1 = {FRAME_crch_dth1_01, FRAME_crch_dth1_18, bitch4_frames_crch_dth1, AI_EndDeath};

mframe_t	bitch4_frames_crch_dth2[] = 
{
	ai_move,	  0.165, NULL,	// frame 0
	ai_move,	 -4.994, NULL,	// frame 1
	ai_move,	-10.808, NULL,	// frame 2
	ai_move,	-18.492, NULL,	// frame 3
	ai_move,	-12.699, NULL,	// frame 4
	ai_move,	  1.597, NULL,	// frame 5
	ai_move,	 -6.449, NULL,	// frame 6
	ai_move,	 -1.806, NULL,	// frame 7
	ai_move,	 -1.587, NULL,	// frame 8
	ai_move,	 -0.255, NULL,	// frame 9
	ai_move,	 -0.102, NULL,	// frame 10
	ai_move,	  0.111, NULL,	// frame 11
	ai_move,	  0.332, NULL,	// frame 12
	ai_move,	 -0.076, NULL,	// frame 13
	ai_move,	 -0.093, NULL,	// frame 14
	ai_move,	 -0.010, NULL,	// frame 15
	ai_move,	  0.030, NULL,	// frame 16
	ai_move,	 -0.028, NULL,	// frame 17
	ai_move,	 -0.008, NULL,	// frame 18
	ai_move,	  0.010, NULL,	// frame 19
};
mmove_t	bitch4_move_crch_dth2 = {FRAME_crch_dth2_01, FRAME_crch_dth2_20, bitch4_frames_crch_dth2, AI_EndDeath};

mframe_t	bitch4_frames_crch_dth3[] = 
{
	ai_move,	  0.314, NULL,	// frame 0
	ai_move,	  1.450, NULL,	// frame 1
	ai_move,	  1.566, NULL,	// frame 2
	ai_move,	  3.095, NULL,	// frame 3
	ai_move,	  3.611, NULL,	// frame 4
	ai_move,	  3.086, NULL,	// frame 5
	ai_move,	  1.937, NULL,	// frame 6
	ai_move,	  3.584, NULL,	// frame 7
	ai_move,	  1.953, NULL,	// frame 8
	ai_move,	 -1.328, NULL,	// frame 9
	ai_move,	  0.703, NULL,	// frame 10
	ai_move,	  1.461, NULL,	// frame 11
	ai_move,	  0.224, NULL,	// frame 12
	ai_move,	  0.003, NULL,	// frame 13
	ai_move,	 -0.014, NULL,	// frame 14
	ai_move,	 -0.011, NULL,	// frame 15
	ai_move,	 -0.006, NULL,	// frame 16
};
mmove_t	bitch4_move_crch_dth3 = {FRAME_crch_dth3_01, FRAME_crch_dth3_17, bitch4_frames_crch_dth3, AI_EndDeath};

mframe_t	bitch4_frames_crch_dth4[] = 
{
	ai_move,	  3.347, NULL,	// frame 0
	ai_move,	  2.696, NULL,	// frame 1
	ai_move,	  3.915, NULL,	// frame 2
	ai_move,	  2.660, NULL,	// frame 3
	ai_move,	 -0.513, NULL,	// frame 4
	ai_move,	  0.444, NULL,	// frame 5
	ai_move,	  0.294, NULL,	// frame 6
	ai_move,	  0.391, NULL,	// frame 7
	ai_move,	  0.410, NULL,	// frame 8
	ai_move,	 -0.087, NULL,	// frame 9
	ai_move,	 -0.443, NULL,	// frame 10
	ai_move,	 -0.331, NULL,	// frame 11
	ai_move,	  0.436, NULL,	// frame 12
	ai_move,	  1.010, NULL,	// frame 13
	ai_move,	  1.466, NULL,	// frame 14
	ai_move,	  2.814, NULL,	// frame 15
	ai_move,	  4.338, NULL,	// frame 16
	ai_move,	  6.705, NULL,	// frame 17
	ai_move,	  3.991, NULL,	// frame 18
	ai_move,	 -2.109, NULL,	// frame 19
	ai_move,	 -0.242, NULL,	// frame 20
	ai_move,	 -0.005, NULL,	// frame 21
	ai_move,	  0.962, NULL,	// frame 22
	ai_move,	 -0.066, NULL,	// frame 23
	ai_move,	 -0.177, NULL,	// frame 24
	ai_move,	  0.016, NULL,	// frame 25
	ai_move,	  0.033, NULL,	// frame 26
	ai_move,	  0.048, NULL,	// frame 27
};
mmove_t	bitch4_move_crch_dth4 = {FRAME_crch_dth4_01, FRAME_crch_dth4_28, bitch4_frames_crch_dth4, AI_EndDeath};

mframe_t	bitch4_frames_crch_knl_dn[] = 
{
//	NULL,	  0.000, NULL,	// frame 0
//	NULL,	  0.000, NULL,	// frame 1
//	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
//	NULL,	  0.000, NULL,	// frame 7
};
mmove_t	bitch4_move_crch_knl_dn = {FRAME_crch_knl_dn_04, FRAME_crch_knl_dn_07, bitch4_frames_crch_knl_dn, AI_EndAttack};

mframe_t	bitch4_frames_stand_up[] = 
{
//	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
//	NULL,	  0.000, NULL,	// frame 5
//	NULL,	  0.000, NULL,	// frame 6
//	NULL,	  0.000, NULL,	// frame 7
};
mmove_t	bitch4_move_stand_up = {FRAME_crch_knl_dn_07, FRAME_crch_knl_dn_04, bitch4_frames_stand_up, AI_EndAttack};

mframe_t	bitch4_frames_crch_amb_std[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
	ai_stand,	  0.000, NULL,	// frame 9
	ai_stand,	  0.000, NULL,	// frame 10
	ai_stand,	  0.000, NULL,	// frame 11
	ai_stand,	  0.000, NULL,	// frame 12
	ai_stand,	  0.000, NULL,	// frame 13
	ai_stand,	  0.000, NULL,	// frame 14
	ai_stand,	  0.000, NULL,	// frame 15
	ai_stand,	  0.000, NULL,	// frame 16
	ai_stand,	  0.000, NULL,	// frame 17
	ai_stand,	  0.000, NULL,	// frame 18
	ai_stand,	  0.000, NULL,	// frame 19
	ai_stand,	  0.000, NULL,	// frame 20
	ai_stand,	  0.000, NULL,	// frame 21
	ai_stand,	  0.000, NULL,	// frame 22
	ai_stand,	  0.000, NULL,	// frame 23
	ai_stand,	  0.000, NULL,	// frame 24
	ai_stand,	  0.000, NULL,	// frame 25
	ai_stand,	  0.000, NULL,	// frame 26
	ai_stand,	  0.000, NULL,	// frame 27
	ai_stand,	  0.000, NULL,	// frame 28
	ai_stand,	  0.000, NULL,	// frame 29
	ai_stand,	  0.000, NULL,	// frame 30
	ai_stand,	  0.000, NULL,	// frame 31
	ai_stand,	  0.000, NULL,	// frame 32
	ai_stand,	  0.000, NULL,	// frame 33
};
mmove_t	bitch4_move_crch_amb_std = {FRAME_crch_amb_std_01, FRAME_crch_amb_std_34, bitch4_frames_crch_amb_std, AI_EndAttack};

mframe_t	bitch4_frames_crch_shoot[] = 
{
	ai_charge,	  0.000, bitch_right_fire,	// frame 0
	ai_charge,	  0.000, NULL,	// frame 1
	ai_charge,	  0.000, NULL,	// frame 2
};
mmove_t	bitch4_move_crch_shoot = {FRAME_crch_shoot_01, FRAME_crch_shoot_03, bitch4_frames_crch_shoot, AI_EndAttack};

mframe_t	bitch4_frames_crch_reload[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
	NULL,	  0.000, NULL,	// frame 9
	NULL,	  0.000, NULL,	// frame 10
	NULL,	  0.000, NULL,	// frame 11
	NULL,	  0.000, NULL,	// frame 12
	NULL,	  0.000, NULL,	// frame 13
	NULL,	  0.000, NULL,	// frame 14
	NULL,	  0.000, NULL,	// frame 15
	NULL,	  0.000, NULL,	// frame 16
	NULL,	  0.000, NULL,	// frame 17
	NULL,	  0.000, NULL,	// frame 18
	NULL,	  0.000, NULL,	// frame 19
	NULL,	  0.000, NULL,	// frame 20
	NULL,	  0.000, NULL,	// frame 21
	NULL,	  0.000, NULL,	// frame 22
	NULL,	  0.000, NULL,	// frame 23
	NULL,	  0.000, NULL,	// frame 24
	NULL,	  0.000, NULL,	// frame 25
	NULL,	  0.000, NULL,	// frame 26
	NULL,	  0.000, NULL,	// frame 27
	NULL,	  0.000, NULL,	// frame 28
	NULL,	  0.000, NULL,	// frame 29
	NULL,	  0.000, NULL,	// frame 30
	NULL,	  0.000, NULL,	// frame 31
	NULL,	  0.000, NULL,	// frame 32
	NULL,	  0.000, NULL,	// frame 33
	NULL,	  0.000, NULL,	// frame 34
};
mmove_t	bitch4_move_crch_reload = {FRAME_crch_reload_01, FRAME_crch_reload_35, bitch4_frames_crch_reload, AI_EndAttack};

mframe_t	bitch4_frames_crch_walk[] = 
{
	ai_run,	  3.161, NULL,	// frame 0
	ai_run,	  5.625, NULL,	// frame 1
	ai_run,	  6.073, NULL,	// frame 2
	ai_run,	  4.260, NULL,	// frame 3
	ai_run,	  3.528, NULL,	// frame 4
	ai_run,	  5.728, NULL,	// frame 5
	ai_run,	  9.076, NULL,	// frame 6
};
mmove_t	bitch4_move_crch_walk = {FRAME_crch_walk_01, FRAME_crch_walk_07, bitch4_frames_crch_walk, NULL};

mframe_t	bitch_frames_walk_dokey[] = 
{
	ai_runDOKEY,	 17.697, EP_ReachedDoKey,	// frame 0
	ai_runDOKEY,	 15.930, EP_ReachedDoKey,	// frame 1
	ai_runDOKEY,	 15.610, EP_ReachedDoKey,	// frame 2
	ai_runDOKEY,	 18.980, EP_ReachedDoKey,	// frame 3
	ai_runDOKEY,	 21.142, EP_ReachedDoKey,	// frame 4
	ai_runDOKEY,	 15.510, EP_ReachedDoKey,	// frame 5
	ai_runDOKEY,	 20.503, EP_ReachedDoKey,	// frame 6
};
mmove_t	bitch_move_walk_dokey = {FRAME_run_guns_dn_01, FRAME_run_guns_dn_07, bitch_frames_walk_dokey, EP_ReachedDoKey};
