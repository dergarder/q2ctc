mframe_t	thug2_frames_sitdn1[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
};
mmove_t	thug2_move_sitdn1 = {FRAME_sitdn1_01, FRAME_sitdn1_12, thug2_frames_sitdn1, thug2_end_stand};

mframe_t	thug2_frames_sitdn2[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
	ai_stand,	  0.000, thug2_talk_think,	// frame 23
	ai_stand,	  0.000, thug2_talk_think,	// frame 24
	ai_stand,	  0.000, thug2_talk_think,	// frame 25
	ai_stand,	  0.000, thug2_talk_think,	// frame 26
	ai_stand,	  0.000, thug2_talk_think,	// frame 27
	ai_stand,	  0.000, thug2_talk_think,	// frame 28
	ai_stand,	  0.000, thug2_talk_think,	// frame 29
	ai_stand,	  0.000, thug2_talk_think,	// frame 30
	ai_stand,	  0.000, thug2_talk_think,	// frame 31
	ai_stand,	  0.000, thug2_talk_think,	// frame 32
	ai_stand,	  0.000, thug2_talk_think,	// frame 33
	ai_stand,	  0.000, thug2_talk_think,	// frame 34
};
mmove_t	thug2_move_sitdn2 = {FRAME_sitdn2_01, FRAME_sitdn2_35, thug2_frames_sitdn2, thug2_end_stand};

mframe_t	thug2_frames_ambsit1[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
	ai_stand,	  0.000, thug2_talk_think,	// frame 23
};
mmove_t	thug2_move_ambsit1 = {FRAME_ambsit1_01, FRAME_ambsit1_24, thug2_frames_ambsit1, thug2_end_stand};

mframe_t	thug2_frames_ambsit2[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
};
mmove_t	thug2_move_ambsit2 = {FRAME_ambsit2_01, FRAME_ambsit2_10, thug2_frames_ambsit2, thug2_end_stand};

mframe_t	thug2_frames_ambsit3[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
};
mmove_t	thug2_move_ambsit3 = {FRAME_ambsit3_01, FRAME_ambsit3_12, thug2_frames_ambsit3, thug2_end_stand};

mframe_t	thug2_frames_ambsit4[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
};
mmove_t	thug2_move_ambsit4 = {FRAME_ambsit4_01, FRAME_ambsit4_13, thug2_frames_ambsit4, thug2_end_stand};

mframe_t	thug2_frames_ambsit5[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
	ai_stand,	  0.000, thug2_talk_think,	// frame 23
	ai_stand,	  0.000, thug2_talk_think,	// frame 24
	ai_stand,	  0.000, thug2_talk_think,	// frame 25
	ai_stand,	  0.000, thug2_talk_think,	// frame 26
	ai_stand,	  0.000, thug2_talk_think,	// frame 27
	ai_stand,	  0.000, thug2_talk_think,	// frame 28
	ai_stand,	  0.000, thug2_talk_think,	// frame 29
};
mmove_t	thug2_move_ambsit5 = {FRAME_ambsit5_01, FRAME_ambsit5_30, thug2_frames_ambsit5, thug2_end_stand};

mframe_t	thug2_frames_ambsit6[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
};
mmove_t	thug2_move_ambsit6 = {FRAME_ambsit6_01, FRAME_ambsit6_23, thug2_frames_ambsit6, thug2_end_stand};

mframe_t	thug2_frames_ambsit7[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
	ai_stand,	  0.000, thug2_talk_think,	// frame 23
	ai_stand,	  0.000, thug2_talk_think,	// frame 24
	ai_stand,	  0.000, thug2_talk_think,	// frame 25
	ai_stand,	  0.000, thug2_talk_think,	// frame 26
	ai_stand,	  0.000, thug2_talk_think,	// frame 27
	ai_stand,	  0.000, thug2_talk_think,	// frame 28
	ai_stand,	  0.000, thug2_talk_think,	// frame 29
	ai_stand,	  0.000, thug2_talk_think,	// frame 30
	ai_stand,	  0.000, thug2_talk_think,	// frame 31
	ai_stand,	  0.000, thug2_talk_think,	// frame 32
	ai_stand,	  0.000, thug2_talk_think,	// frame 33
};
mmove_t	thug2_move_ambsit7 = {FRAME_ambsit7_01, FRAME_ambsit7_34, thug2_frames_ambsit7, thug2_end_stand};

mframe_t	thug2_frames_ambsit8[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
};
mmove_t	thug2_move_ambsit8 = {FRAME_ambsit8_01, FRAME_ambsit8_16, thug2_frames_ambsit8, thug2_end_stand};

mframe_t	thug2_frames_ambsit9[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
	ai_stand,	  0.000, thug2_talk_think,	// frame 23
	ai_stand,	  0.000, thug2_talk_think,	// frame 24
};
mmove_t	thug2_move_ambsit9 = {FRAME_ambsit9_01, FRAME_ambsit9_25, thug2_frames_ambsit9, thug2_end_stand};

mframe_t	thug2_frames_cards1[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
};
mmove_t	thug2_move_cards1 = {FRAME_cards1_01, FRAME_cards1_22, thug2_frames_cards1, thug2_end_stand};

mframe_t	thug2_frames_cards2[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
};
mmove_t	thug2_move_cards2 = {FRAME_cards2_01, FRAME_cards2_16, thug2_frames_cards2, thug2_end_stand};

mframe_t	thug2_frames_cards3[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
	ai_stand,	  0.000, thug2_talk_think,	// frame 23
	ai_stand,	  0.000, thug2_talk_think,	// frame 24
	ai_stand,	  0.000, thug2_talk_think,	// frame 25
	ai_stand,	  0.000, thug2_talk_think,	// frame 26
	ai_stand,	  0.000, thug2_talk_think,	// frame 27
	ai_stand,	  0.000, thug2_talk_think,	// frame 28
	ai_stand,	  0.000, thug2_talk_think,	// frame 29
	ai_stand,	  0.000, thug2_talk_think,	// frame 30
	ai_stand,	  0.000, thug2_talk_think,	// frame 31
	ai_stand,	  0.000, thug2_talk_think,	// frame 32
	ai_stand,	  0.000, thug2_talk_think,	// frame 33
	ai_stand,	  0.000, thug2_talk_think,	// frame 34
	ai_stand,	  0.000, thug2_talk_think,	// frame 35
};
mmove_t	thug2_move_cards3 = {FRAME_cards3_01, FRAME_cards3_36, thug2_frames_cards3, thug2_end_stand};

mframe_t	thug2_frames_cards4[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
	ai_stand,	  0.000, thug2_talk_think,	// frame 20
	ai_stand,	  0.000, thug2_talk_think,	// frame 21
	ai_stand,	  0.000, thug2_talk_think,	// frame 22
	ai_stand,	  0.000, thug2_talk_think,	// frame 23
	ai_stand,	  0.000, thug2_talk_think,	// frame 24
	ai_stand,	  0.000, thug2_talk_think,	// frame 25
	ai_stand,	  0.000, thug2_talk_think,	// frame 26
	ai_stand,	  0.000, thug2_talk_think,	// frame 27
	ai_stand,	  0.000, thug2_talk_think,	// frame 28
	ai_stand,	  0.000, thug2_talk_think,	// frame 29
	ai_stand,	  0.000, thug2_talk_think,	// frame 30
	ai_stand,	  0.000, thug2_talk_think,	// frame 31
	ai_stand,	  0.000, thug2_talk_think,	// frame 32
	ai_stand,	  0.000, thug2_talk_think,	// frame 33
	ai_stand,	  0.000, thug2_talk_think,	// frame 34
	ai_stand,	  0.000, thug2_talk_think,	// frame 35
	ai_stand,	  0.000, thug2_talk_think,	// frame 36
};
mmove_t	thug2_move_cards4 = {FRAME_cards4_01, FRAME_cards4_37, thug2_frames_cards4, thug2_end_stand};

mframe_t	thug2_frames_cards5[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
};
mmove_t	thug2_move_cards5 = {FRAME_cards5_01, FRAME_cards5_14, thug2_frames_cards5, thug2_end_stand};

mframe_t	thug2_frames_cards6[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
	ai_stand,	  0.000, thug2_talk_think,	// frame 18
	ai_stand,	  0.000, thug2_talk_think,	// frame 19
};
mmove_t	thug2_move_cards6 = {FRAME_cards6_01, FRAME_cards6_20, thug2_frames_cards6, thug2_end_stand};

mframe_t	thug2_frames_cards7[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
	ai_stand,	  0.000, thug2_talk_think,	// frame 13
	ai_stand,	  0.000, thug2_talk_think,	// frame 14
	ai_stand,	  0.000, thug2_talk_think,	// frame 15
	ai_stand,	  0.000, thug2_talk_think,	// frame 16
	ai_stand,	  0.000, thug2_talk_think,	// frame 17
};
mmove_t	thug2_move_cards7 = {FRAME_cards7_01, FRAME_cards7_18, thug2_frames_cards7, thug2_end_stand};


mframe_t	thug2_frames_jumpup_nw[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
	ai_stand,	  0.000, NULL,	// frame 9
	ai_stand,	  0.000, NULL,	// frame 10
};
mmove_t	thug2_move_jumpup_nw = {FRAME_jumpup_nw_01, FRAME_jumpup_nw_11, thug2_frames_jumpup_nw, thug2_end_standup};

mframe_t	thug2_frames_jumpup_g[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
};
mmove_t	thug2_move_jumpup_g = {FRAME_jumpup_g_01, FRAME_jumpup_g_09, thug2_frames_jumpup_g, thug2_end_standup};

mframe_t	thug2_frames_ambstand1[] = 
{
	ai_stand,	  0.000, thug2_talk_think,	// frame 0
	ai_stand,	  0.000, thug2_talk_think,	// frame 1
	ai_stand,	  0.000, thug2_talk_think,	// frame 2
	ai_stand,	  0.000, thug2_talk_think,	// frame 3
	ai_stand,	  0.000, thug2_talk_think,	// frame 4
	ai_stand,	  0.000, thug2_talk_think,	// frame 5
	ai_stand,	  0.000, thug2_talk_think,	// frame 6
	ai_stand,	  0.000, thug2_talk_think,	// frame 7
	ai_stand,	  0.000, thug2_talk_think,	// frame 8
	ai_stand,	  0.000, thug2_talk_think,	// frame 9
	ai_stand,	  0.000, thug2_talk_think,	// frame 10
	ai_stand,	  0.000, thug2_talk_think,	// frame 11
	ai_stand,	  0.000, thug2_talk_think,	// frame 12
};
mmove_t	thug2_move_ambstand1 = {FRAME_ambstand1_01, FRAME_ambstand1_13, thug2_frames_ambstand1, thug2_end_stand};

mframe_t	thug2_frames_ambstand2[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
};
mmove_t	thug2_move_ambstand2 = {FRAME_ambstand2_01, FRAME_ambstand2_03, thug2_frames_ambstand2, thug2_end_stand};

mframe_t	thug2_frames_surrender[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
};
mmove_t	thug2_move_surrender = {FRAME_surrender_01, FRAME_surrender_08, thug2_frames_surrender, NULL};

mframe_t	thug2_frames_surr2std[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
};
mmove_t	thug2_move_surr2std = {FRAME_surr2std_01, FRAME_surr2std_06, thug2_frames_surr2std, NULL};



mframe_t	thug2_frames_pull_guns[] = 
{
	ai_turn,	  0.000, NULL,	// frame 0
	ai_turn,	  0.000, NULL,	// frame 1
	ai_turn,	  0.000, thug2_show_guns,	// frame 2
	ai_turn,	  0.000, NULL,	// frame 3
	ai_turn,	  0.000, NULL,	// frame 4
	ai_turn,	  0.000, NULL,	// frame 5
	ai_turn,	  0.000, NULL,	// frame 6
	ai_turn,	  0.000, NULL,	// frame 7
};
mmove_t	thug2_move_pull_guns = {FRAME_pull_guns_01, FRAME_pull_guns_08, thug2_frames_pull_guns, AI_EndAttack};

mframe_t	thug2_frames_shoot[] = 
{
	ai_turn,	  0.000, thug2_left_fire,	// frame 0
	ai_turn,	  0.000, NULL,	// frame 1
	ai_turn,	  0.000, thug2_right_fire,	// frame 2
	ai_turn,	  0.000, NULL,	// frame 3
};
mmove_t	thug2_move_shoot = {FRAME_shoot_01, FRAME_shoot_04, thug2_frames_shoot, AI_EndAttack};

mframe_t	thug2_frames_reload[] = 
{
	ai_turn,	  0.000, NULL,	// frame 0
	ai_turn,	  0.000, NULL,	// frame 1
	ai_turn,	  0.000, NULL,	// frame 2
	ai_turn,	  0.000, NULL,	// frame 3
	ai_turn,	  0.000, NULL,	// frame 4
	ai_turn,	  0.000, NULL,	// frame 5
	ai_turn,	  0.000, NULL,	// frame 6
	ai_turn,	  0.000, NULL,	// frame 7
	ai_turn,	  0.000, NULL,	// frame 8
	ai_turn,	  0.000, NULL,	// frame 9
	ai_turn,	  0.000, NULL,	// frame 10
	ai_turn,	  0.000, NULL,	// frame 11
	ai_turn,	  0.000, NULL,	// frame 12
};
mmove_t	thug2_move_reload = {FRAME_reload_01, FRAME_reload_13, thug2_frames_reload, AI_EndAttack};

mframe_t	thug2_frames_kneel[] = 
{
	ai_charge,	  0.000, NULL,	// frame 0
	ai_charge,	  0.000, thug2_show_guns,	// frame 1
	ai_charge,	  0.000, NULL,	// frame 2
	ai_charge,	  0.000, NULL,	// frame 3
	ai_charge,	  0.000, NULL,	// frame 4
	ai_charge,	  0.000, NULL,	// frame 5
	ai_charge,	  0.000, NULL,	// frame 6
};
mmove_t	thug2_move_kneel = {FRAME_kneel_01, FRAME_kneel_07, thug2_frames_kneel, thug2_kneel_shoot};

mframe_t	thug2_frames_kneel_up[] = 
{
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 0
};
mmove_t	thug2_move_kneel_up = {FRAME_kneel_07, FRAME_kneel_01, thug2_frames_kneel_up, AI_EndAttack};

mframe_t	thug2_frames_knl_shoot[] = 
{
	NULL,	  0.000, thug2_right_fire,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, thug2_left_fire,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
};
mmove_t	thug2_move_knl_shoot = {FRAME_knl_shoot_01, FRAME_knl_shoot_06, thug2_frames_knl_shoot, thug2_end_kneel_attack};

mframe_t	thug2_frames_melee1[] = 
{
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 0
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 1
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 2
	ai_turn2,	  0.000, thug2_melee,	// frame 4
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 5
	ai_turn2,	  0.000, thug2_melee,	// frame 7
	ai_turn2,	  0.000, NULL,	// frame 9
	ai_turn2,	  0.000, NULL,	// frame 10
};
mmove_t	thug2_move_melee1 = {FRAME_melee1_01, FRAME_melee1_08, thug2_frames_melee1, AI_EndAttack};

mframe_t	thug2_frames_melee2[] = 
{
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 0
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 1
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 3
	ai_turn2,	  0.000, thug2_melee,	// frame 4
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 6
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 7
	ai_turn2,	  0.000, thug2_melee,	// frame 8
	ai_turn2,	  0.000, NULL,	// frame 10
	ai_turn2,	  0.000, NULL,	// frame 8
};
mmove_t	thug2_move_melee2 = {FRAME_melee2_01, FRAME_melee2_09, thug2_frames_melee2, AI_EndAttack};

mframe_t	thug2_frames_melee3[] = 
{
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 0
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 2
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 3
	ai_turn2,	  0.000, thug2_melee,	// frame 4
	ai_turn2,	  0.000, NULL,	// frame 7
	ai_turn2,	  0.000, NULL,	// frame 8
	ai_turn2,	  0.000, NULL,	// frame 9
};
mmove_t	thug2_move_melee3 = {FRAME_melee3_01, FRAME_melee3_07, thug2_frames_melee3, AI_EndAttack};

mframe_t	thug2_frames_melee4[] = 
{
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 0
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 1
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 3
	ai_turn2,	  0.000, thug2_melee,	// frame 4
	ai_turn2,	  0.000, NULL,	// frame 7
	ai_turn2,	  0.000, NULL,	// frame 8
};
mmove_t	thug2_move_melee4 = {FRAME_melee4_01, FRAME_melee4_06, thug2_frames_melee4, AI_EndAttack};

mframe_t	thug2_frames_melee5[] = 
{
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 0
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 1
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 3
	ai_turn2,	  0.000, thug2_melee_bail,	// frame 4
	ai_turn2,	  0.000, thug2_melee,	// frame 5
	ai_turn2,	  0.000, NULL,	// frame 8
	ai_turn2,	  0.000, NULL,	// frame 9
};
mmove_t	thug2_move_melee5 = {FRAME_melee5_01, FRAME_melee5_07, thug2_frames_melee5, AI_EndAttack};

mframe_t	thug2_frames_run_melee[] = 
{
	ai_charge,	  0.000, NULL,	// frame 0
	ai_charge,	 20.696, NULL,	// frame 1
	ai_charge,	 26.558, NULL,	// frame 2
	ai_charge,	 34.731, thug2_melee,	// frame 3
	ai_charge,	 33.953, NULL,	// frame 4
	ai_charge,	 28.473, NULL,	// frame 5
};
mmove_t	thug2_move_run_melee = {FRAME_run_melee_01, FRAME_run_melee_06, thug2_frames_run_melee, AI_EndAttack};

mframe_t	thug2_frames_jump[] = 
{
//	ai_stand,	  0.000, NULL,	// frame 0
//	ai_stand,	  0.000, NULL,	// frame 1
//	ai_stand,	  0.000, NULL,	// frame 2
//	ai_stand,	  0.000, NULL,	// frame 3
//	ai_stand,	  0.000, NULL,	// frame 4

	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, AI_CheckStillInair,	// frame 7
	NULL,	  0.000, NULL,	// frame 8

//	ai_stand,	  0.000, NULL,	// frame 9
//	ai_stand,	  0.000, NULL,	// frame 10
//	ai_stand,	  0.000, NULL,	// frame 11
//	ai_stand,	  0.000, NULL,	// frame 12
//	ai_stand,	  0.000, NULL,	// frame 13
//	ai_stand,	  0.000, NULL,	// frame 14
//	ai_stand,	  0.000, NULL,	// frame 15
//	ai_stand,	  0.000, NULL,	// frame 16
};
mmove_t	thug2_move_jump = {FRAME_jump_05, FRAME_jump_08, thug2_frames_jump, AI_EndJump};

mframe_t	thug2_frames_walk_shoot[] = 
{
	ai_charge,	  7.047, thug2_left_fire,	// frame 0
	ai_charge,	  5.998, NULL,	// frame 1
	ai_charge,	  3.820, NULL,	// frame 2
	ai_charge,	  7.507, NULL,	// frame 3
	ai_charge,	  8.655, thug2_right_fire,	// frame 4
	ai_charge,	  9.650, NULL,	// frame 5
	ai_charge,	  0.565, NULL,	// frame 6
	ai_charge,	 13.452, NULL,	// frame 7
	ai_charge,	  7.716, thug2_left_fire,	// frame 8
	ai_charge,	  8.753, NULL,	// frame 9
};
mmove_t	thug2_move_walk_shoot = {FRAME_walk_shoot_01, FRAME_walk_shoot_10, thug2_frames_walk_shoot, AI_EndAttack};

mframe_t	thug2_frames_reverse_walk_shoot[] = 
{
	ai_charge,-	  7.047, thug2_left_fire,	// frame 0
	ai_charge,-	  5.998, NULL,	// frame 1
	ai_charge,-	  3.820, NULL,	// frame 2
	ai_charge,-	  7.507, NULL,	// frame 3
	ai_charge,-	  8.655, thug2_right_fire,	// frame 4
	ai_charge,-	  9.650, NULL,	// frame 5
	ai_charge,-	  0.565, NULL,	// frame 6
	ai_charge,-	 13.452, NULL,	// frame 7
	ai_charge,-	  7.716, thug2_left_fire,	// frame 8
	ai_charge,-	  8.753, NULL,	// frame 9
};
mmove_t	thug2_move_reverse_walk_shoot = {FRAME_walk_shoot_10, FRAME_walk_shoot_01, thug2_frames_reverse_walk_shoot, AI_EndAttack};

mframe_t	thug2_frames_walk_guns_dn[] = 
{
	ai_run,	    0.834, NULL,	// frame 0
	ai_run,	    2.767, NULL,	// frame 1
	ai_run,	    5.854, NULL,	// frame 2
	ai_run,	    3.947, NULL,	// frame 3
	ai_run,	    8.270, NULL,	// frame 4
	ai_run,	    4.192, NULL,	// frame 5
	ai_run,	   13.362, NULL,	// frame 6
	ai_run,	   12.064, NULL,	// frame 7
	ai_run,	   14.928, NULL,	// frame 8
	ai_run,	    6.636, NULL,	// frame 9
};
mmove_t	thug2_move_walk_guns_dn = {FRAME_walk_guns_dn_01, FRAME_walk_guns_dn_10, thug2_frames_walk_guns_dn, NULL};

mframe_t	thug2_frames_avoid_walk[] = 
{
	ai_turn,    0.834, NULL,	// frame 0
	ai_turn,    2.767, NULL,	// frame 1
	ai_turn,    5.854, NULL,	// frame 2
	ai_turn,    3.947, NULL,	// frame 3
	ai_turn,    8.270, NULL,	// frame 4
	ai_turn,    4.192, NULL,	// frame 5
	ai_turn,   13.362, NULL,	// frame 6
	ai_turn,   12.064, NULL,	// frame 7
	ai_turn,   14.928, NULL,	// frame 8
	ai_turn,    6.636, NULL,	// frame 9
};
mmove_t	thug2_move_avoid_walk = {FRAME_walk_guns_dn_01, FRAME_walk_guns_dn_10, thug2_frames_avoid_walk, AI_EndAttack};

mframe_t thug2_frames_avoid_reverse_walk[] = 
{
	ai_turn,	 -6.636, NULL,	// frame 0
	ai_turn,	-14.928, NULL,	// frame 1
	ai_turn,	-12.064, NULL,	// frame 2
	ai_turn,	-13.362, NULL,	// frame 3
	ai_turn,	 -4.192, NULL,	// frame 4
	ai_turn,     -8.270, NULL,	// frame 5
	ai_turn,     -3.947, NULL,	// frame 6
	ai_turn,     -5.854, NULL,	// frame 7
	ai_turn,     -2.767, NULL,	// frame 8
	ai_turn,	 -0.834, NULL,	// frame 9
};
mmove_t	thug2_move_avoid_reverse_walk = {FRAME_walk_guns_dn_10, FRAME_walk_guns_dn_01, thug2_frames_avoid_reverse_walk, AI_EndAttack};

mframe_t	thug2_frames_avoid_run[] = 
{
	ai_turn,	 -1.047, NULL,	// frame 0
	ai_turn,	  8.567, NULL,	// frame 1
	ai_turn,	 10.335, NULL,	// frame 2
	ai_turn,	 13.799, NULL,	// frame 3
	ai_turn,	 11.656, NULL,	// frame 4
	ai_turn,	 11.956, NULL,	// frame 5
};
mmove_t	thug2_move_avoid_run = {FRAME_run_guns_dn_01, FRAME_run_guns_dn_06, thug2_frames_avoid_run, AI_EndAttack};

mframe_t	thug2_frames_avoid_reverse_run[] = 
{
	ai_turn,	-11.956, NULL,	// frame 5
	ai_turn,	-11.656, NULL,	// frame 4
	ai_turn,	-13.799, NULL,	// frame 3
	ai_turn,	-10.335, NULL,	// frame 2
	ai_turn,	- 8.567, NULL,	// frame 1
	ai_turn,	  1.047, NULL,	// frame 0
};
mmove_t	thug2_move_avoid_reverse_run = {FRAME_run_guns_dn_06, FRAME_run_guns_dn_01, thug2_frames_avoid_reverse_run, AI_EndAttack};

mframe_t	thug2_frames_run_shoot[] = 
{
	ai_run,	 -0.390, thug2_right_fire,	// frame 0
	ai_run,	 27.006, thug2_left_fire,	// frame 1
	ai_run,	 35.956, NULL,	// frame 2
	ai_run,	 35.864, thug2_right_fire,	// frame 3
	ai_run,	 30.130, NULL,	// frame 4
	ai_run,	 25.292, thug2_left_fire,	// frame 5
};
mmove_t	thug2_move_run_shoot = {FRAME_run_shoot_01, FRAME_run_shoot_06, thug2_frames_run_shoot, AI_EndAttack};

mframe_t	thug2_frames_run_guns_dn[] = 
{
	ai_run,	 -0.303, NULL,	// frame 0
	ai_run,	 17.188, NULL,	// frame 1
	ai_run,	 31.486, NULL,	// frame 2
	ai_run,	 31.052, NULL,	// frame 3
	ai_run,	 23.944, NULL,	// frame 4
	ai_run,	 24.549, NULL,	// frame 5
};
mmove_t	thug2_move_run_guns_dn = {FRAME_run_guns_dn_01, FRAME_run_guns_dn_06, thug2_frames_run_guns_dn, NULL};

mframe_t	thug2_frames_run_on_fire[] = 
{
	ai_onfire_run,	 -4.097, NULL,	// frame 0
	ai_onfire_run,	 20.973, NULL,	// frame 1
	ai_onfire_run,	 44.080, NULL,	// frame 2
	ai_onfire_run,	 30.029, NULL,	// frame 3
	ai_onfire_run,	 25.538, NULL,	// frame 4
	ai_onfire_run,	 26.007, NULL,	// frame 5
};
mmove_t	thug2_move_run_on_fire = {FRAME_run_on_fire_01, FRAME_run_on_fire_06, thug2_frames_run_on_fire, NULL};

// who would guess its backwards at least for today...
mframe_t	thug2_frames_lside_run[] = 
{
	ai_sidestep,  12.636, thug2_firegun_left,	// frame 0
	ai_sidestep,  20.416, NULL,	// frame 1
	ai_sidestep,  34.221, NULL,	// frame 2
	ai_sidestep,  29.869, thug2_firegun_left,	// frame 3
	ai_sidestep,  24.720, NULL,	// frame 4
	ai_sidestep,  20.704, NULL,	// frame 5
};
// mmove_t	thug2_move_lside_run = {FRAME_lside_run_01, FRAME_lside_run_06, thug2_frames_lside_run, NULL};
mmove_t	thug2_move_lside_run = {FRAME_rside_run_01, FRAME_rside_run_06, thug2_frames_lside_run, NULL};

mframe_t	thug2_frames_rside_run[] = 
{
	ai_sidestep, -18.101, thug2_firegun_right,	// frame 0
	ai_sidestep, -21.618, NULL,	// frame 1
	ai_sidestep, -26.521, NULL,	// frame 2
	ai_sidestep, -15.259, NULL,	// frame 3
	ai_sidestep, -27.243, thug2_firegun_right,	// frame 4
	ai_sidestep, -23.765, NULL,	// frame 5
};
// mmove_t	thug2_move_rside_run = {FRAME_rside_run_01, FRAME_rside_run_06, thug2_frames_rside_run, NULL};
mmove_t	thug2_move_rside_run = {FRAME_lside_run_01, FRAME_lside_run_06, thug2_frames_rside_run, NULL};

mframe_t	thug2_frames_lside_step[] = 
{
	ai_sidestep,	-0.530, NULL,	// frame 0
	ai_sidestep,	0.931, NULL,	// frame 1
	ai_sidestep,	3.156, NULL,	// frame 2
	ai_sidestep,	3.382, NULL,	// frame 3
	ai_sidestep,	2.187, NULL,	// frame 4
	ai_sidestep,	3.987, NULL,	// frame 5
	ai_sidestep,	-0.497, NULL,	// frame 6
};
mmove_t	thug2_move_lside_step = {FRAME_lside_step_01, FRAME_lside_step_07, thug2_frames_lside_step, AI_EndAttack};

mframe_t	thug2_frames_rside_step[] = 
{
	ai_sidestep,	 -0.710, NULL,	// frame 0
	ai_sidestep,	 -2.559, NULL,	// frame 1
	ai_sidestep,	  0.032, NULL,	// frame 2
	ai_sidestep,	 -1.031, NULL,	// frame 3
	ai_sidestep,	 -3.099, NULL,	// frame 4
	ai_sidestep,	 -1.713, NULL,	// frame 5
	ai_sidestep,	 -2.924, NULL,	// frame 6
};
mmove_t	thug2_move_rside_step = {FRAME_rside_step_01, FRAME_rside_step_07, thug2_frames_rside_step, AI_EndAttack};

mframe_t	thug2_frames_evade[] = 
{
	ai_turn,	 -0.296, NULL,	// frame 0
	ai_turn,	  1.630, NULL,	// frame 1
	ai_turn,	  0.455, NULL,	// frame 2
	ai_turn,	 -7.690, NULL,	// frame 3
	ai_turn,	 -3.309, NULL,	// frame 4
	ai_turn,	-13.075, NULL,	// frame 5
	ai_turn,	 -3.790, NULL,	// frame 6
	ai_turn,	-11.745, NULL,	// frame 7
	ai_turn,	 -5.925, NULL,	// frame 8
	ai_turn,	 -0.171, NULL,	// frame 9
	ai_turn,	 -5.828, NULL,	// frame 10
	ai_turn,	 -2.348, NULL,	// frame 11
	ai_turn,	 -0.799, NULL,	// frame 12
};
mmove_t	thug2_move_evade = {FRAME_evade_01, FRAME_evade_13, thug2_frames_evade, thug2_evade_amb};

mframe_t	thug2_frames_evade_amb[] = 
{
	NULL,	  0.000, thug2_evade_checkadjust,	// frame 0
	NULL,	  0.000, thug2_evade_checkadjust,	// frame 1
	NULL,	  0.000, thug2_evade_checkadjust,	// frame 2
	NULL,	  0.000, thug2_evade_checkadjust,	// frame 3
	NULL,	  0.000, thug2_evade_checkadjust,	// frame 4
	NULL,	  0.000, thug2_evade_checkadjust,	// frame 5
	NULL,	  0.000, thug2_evade_checkadjust,	// frame 6
};
mmove_t	thug2_move_evade_amb = {FRAME_evade_amb_01, FRAME_evade_amb_07, thug2_frames_evade_amb, AI_CheckEvade};

mframe_t	thug2_frames_evade_stand[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
};
mmove_t	thug2_move_evade_stand = {FRAME_evade_amb_01, FRAME_evade_amb_07, thug2_frames_evade_stand, thug2_end_stand};

mframe_t	thug2_frames_evade_adjust[] = 
{
	ai_turn,	 -1.430, thug2_evade_adjust,	// frame 9
	ai_turn,	 -5.835, thug2_evade_adjust,	// frame 10
	ai_turn,	 -1.706, thug2_evade_adjust,	// frame 11
	ai_turn,	 -0.040, thug2_evade_adjust,	// frame 12
};
mmove_t	thug2_move_evade_adjust = {FRAME_evade_10, FRAME_evade_13, thug2_frames_evade_adjust, thug2_evade_amb};

/*
mframe_t	thug2_frames_st_clmb[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
};
mmove_t	thug2_move_st_clmb = {FRAME_st_clmb_01, FRAME_st_clmb_02, thug2_frames_st_clmb, thug2_climb_loop};
*/
mframe_t	thug2_frames_clmb_loop[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
};
mmove_t	thug2_move_clmb_loop = {FRAME_clmb_loop_01, FRAME_clmb_loop_09, thug2_frames_clmb_loop, AI_CheckStillClimbingLadder};

/*
mframe_t	thug2_frames_clmb_jmp[] = 
{
	NULL,	  0.000, AI_CheckStillInair,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
};
mmove_t	thug2_move_clmb_jmp = {FRAME_clmb_jmp_dn_01, FRAME_clmb_jmp_dn_06, thug2_frames_clmb_jmp, AI_EndJump};
*/

mframe_t	thug2_frames_clmb_jmp[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, AI_CheckStillInair,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
//	NULL,	  0.000, NULL,	// frame 9
//	NULL,	  0.000, NULL,	// frame 10
//	NULL,	  0.000, NULL,	// frame 11
//	NULL,	  0.000, NULL,	// frame 12
//	NULL,	  0.000, NULL,	// frame 13
//	NULL,	  0.000, NULL,	// frame 14
};
mmove_t	thug2_move_clmb_jmp = {FRAME_clmb_over_01, FRAME_clmb_over_09, thug2_frames_clmb_jmp, AI_EndJump};


mframe_t	thug2_frames_clmb_over[] = 
{
	NULL,	  0.000, AI_CheckStillInair,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
	NULL,	  0.000, NULL,	// frame 9
	NULL,	  0.000, NULL,	// frame 10
	NULL,	  0.000, NULL,	// frame 11
	NULL,	  0.000, NULL,	// frame 12
	NULL,	  0.000, NULL,	// frame 13
	NULL,	  0.000, NULL,	// frame 14
};
mmove_t	thug2_move_clmb_over = {FRAME_clmb_over_01, FRAME_clmb_over_15, thug2_frames_clmb_over, AI_EndJump};

/*
mframe_t	thug2_frames_pain1[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
};
mmove_t	thug2_move_pain1 = {FRAME_pain1_01, FRAME_pain1_05, thug2_frames_pain1, AI_EndAttack};

mframe_t	thug2_frames_pain2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
};
mmove_t	thug2_move_pain2 = {FRAME_pain2_01, FRAME_pain2_05, thug2_frames_pain2, AI_EndAttack};

mframe_t	thug2_frames_pain3[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
};
mmove_t	thug2_move_pain3 = {FRAME_pain3_01, FRAME_pain3_05, thug2_frames_pain3, AI_EndAttack};


*/

mframe_t	thug2_frames_crch_dth[] = 
{
	ai_move,	 -1.942, NULL,	// frame 0
	ai_move,	 -8.438, NULL,	// frame 1
	ai_move,	 -7.796, NULL,	// frame 2
	ai_move,	-10.572, NULL,	// frame 3
	ai_move,	 -6.917, NULL,	// frame 4
	ai_move,	 -7.397, NULL,	// frame 5
	ai_move,	-12.057, NULL,	// frame 6
	ai_move,	 -1.582, NULL,	// frame 7
	ai_move,	  0.216, NULL,	// frame 8
	ai_move,	  0.493, NULL,	// frame 9
	ai_move,	 -0.908, NULL,	// frame 10
	ai_move,	  0.971, NULL,	// frame 11
	ai_move,	 -0.692, NULL,	// frame 12
	ai_move,	 -0.122, NULL,	// frame 13
	ai_move,	  0.079, NULL,	// frame 14
	ai_move,	 -0.098, NULL,	// frame 15
	ai_move,	 -0.082, NULL,	// frame 16
	ai_move,	 -0.019, NULL,	// frame 17
	ai_move,	 -0.032, NULL,	// frame 18
};
mmove_t	thug2_move_crch_dth = {FRAME_crch_dth_01, FRAME_crch_dth_19, thug2_frames_crch_dth, AI_EndDeath};

mframe_t	thug2_frames_crch_knl_dn[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
};
mmove_t	thug2_move_crch_knl_dn = {FRAME_crch_knl_dn_01, FRAME_crch_knl_dn_04, thug2_frames_crch_knl_dn, AI_EndAttack};

mframe_t	thug2_frames_stand_up[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
};
mmove_t	thug2_move_stand_up = {FRAME_crch_knl_dn_04, FRAME_crch_knl_dn_01, thug2_frames_stand_up, AI_EndAttack};

mframe_t	thug2_frames_crch_amb_sdt[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
	ai_stand,	  0.000, NULL,	// frame 9
	ai_stand,	  0.000, NULL,	// frame 10
	ai_stand,	  0.000, NULL,	// frame 11
	ai_stand,	  0.000, NULL,	// frame 12
	ai_stand,	  0.000, NULL,	// frame 13
	ai_stand,	  0.000, NULL,	// frame 14
	ai_stand,	  0.000, NULL,	// frame 15
	ai_stand,	  0.000, NULL,	// frame 16
	ai_stand,	  0.000, NULL,	// frame 17
	ai_stand,	  0.000, NULL,	// frame 18
	ai_stand,	  0.000, NULL,	// frame 19
	ai_stand,	  0.000, NULL,	// frame 20
	ai_stand,	  0.000, NULL,	// frame 21
	ai_stand,	  0.000, NULL,	// frame 22
	ai_stand,	  0.000, NULL,	// frame 23
};
mmove_t	thug2_move_crch_amb_sdt = {FRAME_crch_amb_sdt_01, FRAME_crch_amb_sdt_24, thug2_frames_crch_amb_sdt, NULL};

mframe_t	thug2_frames_crch_shoot[] = 
{
	ai_turn,	  0.000, thug2_right_fire,	// frame 0
	ai_turn,	  0.000, NULL,	// frame 1
	ai_turn,	  0.000, NULL,	// frame 2
	ai_turn,	  0.000, thug2_left_fire,	// frame 3
	ai_turn,	  0.000, NULL,	// frame 4
};
mmove_t	thug2_move_crch_shoot = {FRAME_crch_shoot_01, FRAME_crch_shoot_05, thug2_frames_crch_shoot, AI_EndAttack};

mframe_t	thug2_frames_crouch_avoid_walk[] = 
{
	ai_turn,	  8.894, NULL,	// frame 0
	ai_turn,	  3.409, NULL,	// frame 1
	ai_turn,	  2.605, NULL,	// frame 2
	ai_turn,	  3.897, NULL,	// frame 3
	ai_turn,	  6.927, NULL,	// frame 4
	ai_turn,	  8.337, NULL,	// frame 5
};
mmove_t	thug2_move_crouch_avoid_walk = {FRAME_crouch_shfl_01, FRAME_crouch_shfl_06, thug2_frames_crouch_avoid_walk, AI_EndAttack};

mframe_t	thug2_frames_crouch_shfl[] = 
{
	ai_run,	  8.894, NULL,	// frame 0
	ai_run,	  3.409, NULL,	// frame 1
	ai_run,	  2.605, NULL,	// frame 2
	ai_run,	  3.897, NULL,	// frame 3
	ai_run,	  6.927, NULL,	// frame 4
	ai_run,	  8.337, NULL,	// frame 5
};
mmove_t	thug2_move_crouch_shfl = {FRAME_crouch_shfl_01, FRAME_crouch_shfl_06, thug2_frames_crouch_shfl, NULL};

mframe_t	thug2_frames_crouch_walk[] = 
{
	ai_run,	  6.183, NULL,	// frame 0
	ai_run,	 10.404, NULL,	// frame 1
	ai_run,	  6.033, NULL,	// frame 2
	ai_run,	 16.049, NULL,	// frame 3
	ai_run,	 10.574, NULL,	// frame 4
	ai_run,	 12.539, NULL,	// frame 5
};
mmove_t	thug2_move_crouch_walk = {FRAME_crouch_walk_01, FRAME_crouch_walk_06, thug2_frames_crouch_walk, NULL};

mframe_t	thug2_frames_crouch_pain1[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
};
mmove_t	thug2_move_crouch_pain1 = {FRAME_crouch_pain1_01, FRAME_crouch_pain1_08, thug2_frames_crouch_pain1, AI_EndAttack};

mframe_t	thug2_frames_crouch_pain2[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
};
mmove_t	thug2_move_crouch_pain2 = {FRAME_crouch_pain2_01, FRAME_crouch_pain2_06, thug2_frames_crouch_pain2, AI_EndAttack};

mframe_t	thug2_frames_crouch_pain3[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
};
mmove_t	thug2_move_crouch_pain3 = {FRAME_crouch_pain3_01, FRAME_crouch_pain3_06, thug2_frames_crouch_pain3, AI_EndAttack};

mframe_t thug2_frames_low_melee1[] = 
{
 ai_charge,   0.000, thug2_melee_bail, // frame 0
 ai_charge,   0.000, thug2_melee_bail, // frame 1
 ai_charge,   0.000, thug2_melee_bail, // frame 2
 ai_charge,   0.000, thug2_melee_bail, // frame 3
 ai_charge,   0.000, thug2_melee, // frame 4
 ai_charge,   0.000, NULL, // frame 5
 ai_charge,   0.000, NULL, // frame 6
 ai_charge,   0.000, NULL, // frame 7
 ai_charge,   0.000, NULL, // frame 8
 ai_charge,   0.000, NULL, // frame 9
};
mmove_t thug2_move_low_melee1 = {FRAME_low_melee1_01, FRAME_low_melee1_10, thug2_frames_low_melee1, AI_EndAttack};

// new pains and death

mframe_t	thug2_frames_pain_Rarm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
};
mmove_t	thug2_move_pain_Rarm = {FRAME_pain_Rarm_01, FRAME_pain_Rarm_10, thug2_frames_pain_Rarm, AI_EndAttack};

mframe_t	thug2_frames_pain_Larm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	thug2_move_pain_Larm = {FRAME_pain_Larm_01, FRAME_pain_Larm_09, thug2_frames_pain_Larm, AI_EndAttack};

mframe_t	thug2_frames_pain_chest[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	thug2_move_pain_chest = {FRAME_pain_chest_01, FRAME_pain_chest_09, thug2_frames_pain_chest, AI_EndAttack};

mframe_t	thug2_frames_pain_head[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
};
mmove_t	thug2_move_pain_head = {FRAME_pain_head_01, FRAME_pain_head_10, thug2_frames_pain_head, AI_EndAttack};

mframe_t	thug2_frames_pain_Rleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
};
mmove_t	thug2_move_pain_Rleg = {FRAME_pain_Rleg_01, FRAME_pain_Rleg_10, thug2_frames_pain_Rleg, AI_EndAttack};

mframe_t	thug2_frames_pain_Lleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
};
mmove_t	thug2_move_pain_Lleg = {FRAME_pain_Lleg_01, FRAME_pain_Lleg_08, thug2_frames_pain_Lleg, AI_EndAttack};

mframe_t	thug2_frames_pain_crch[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
};
mmove_t	thug2_move_pain_crch = {FRAME_pain_crch_01, FRAME_pain_crch_11, thug2_frames_pain_crch, AI_EndAttack};

mframe_t	thug2_frames_pain_butt[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	thug2_move_pain_butt = {FRAME_pain_butt_01, FRAME_pain_butt_09, thug2_frames_pain_butt, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_Rarm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
};
mmove_t	thug2_move_nw_pain_Rarm = {FRAME_nw_pain_Rarm_01, FRAME_nw_pain_Rarm_11, thug2_frames_nw_pain_Rarm, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_Larm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
};
mmove_t	thug2_move_nw_pain_Larm = {FRAME_nw_pain_Larm_01, FRAME_nw_pain_Larm_11, thug2_frames_nw_pain_Larm, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_chst[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
};
mmove_t	thug2_move_nw_pain_chst = {FRAME_nw_pain_chst_01, FRAME_nw_pain_chst_11, thug2_frames_nw_pain_chst, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_head[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
};
mmove_t	thug2_move_nw_pain_head = {FRAME_nw_pain_head_01, FRAME_nw_pain_head_08, thug2_frames_nw_pain_head, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_Rleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
};
mmove_t	thug2_move_nw_pain_Rleg = {FRAME_nw_pain_Rleg_01, FRAME_nw_pain_Rleg_10, thug2_frames_nw_pain_Rleg, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_Lleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
	ai_move,	  0.000, NULL,	// frame 11
	ai_move,	  0.000, NULL,	// frame 12
};
mmove_t	thug2_move_nw_pain_Lleg = {FRAME_nw_pain_Lleg_01, FRAME_nw_pain_Lleg_13, thug2_frames_nw_pain_Lleg, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_crch[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
	ai_move,	  0.000, NULL,	// frame 11
	ai_move,	  0.000, NULL,	// frame 12
	ai_move,	  0.000, NULL,	// frame 13
	ai_move,	  0.000, NULL,	// frame 14
	ai_move,	  0.000, NULL,	// frame 15
};
mmove_t	thug2_move_nw_pain_crch = {FRAME_nw_pain_crch_01, FRAME_nw_pain_crch_16, thug2_frames_nw_pain_crch, AI_EndAttack};

mframe_t	thug2_frames_nw_pain_butt[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
	ai_move,	  0.000, NULL,	// frame 11
	ai_move,	  0.000, NULL,	// frame 12
	ai_move,	  0.000, NULL,	// frame 13
};
mmove_t	thug2_move_nw_pain_butt = {FRAME_nw_pain_butt_01, FRAME_nw_pain_butt_14, thug2_frames_nw_pain_butt, AI_EndAttack};

mframe_t	thug2_frames_death1[] = 
{
	ai_move,	 -5.521, NULL,	// frame 0
	ai_move,	-12.982, NULL,	// frame 1
	ai_move,	 -5.191, NULL,	// frame 2
	ai_move,	-12.777, NULL,	// frame 3
	ai_move,	-12.240, NULL,	// frame 4
	ai_move,	 -6.917, NULL,	// frame 5
	ai_move,	 -7.750, NULL,	// frame 6
	ai_move,	  0.493, NULL,	// frame 7
	ai_move,	  2.456, NULL,	// frame 8
	ai_move,	  0.524, NULL,	// frame 9
	ai_move,	  3.357, NULL,	// frame 10
	ai_move,	  1.128, NULL,	// frame 11
	ai_move,	 -0.663, NULL,	// frame 12
	ai_move,	 -0.169, NULL,	// frame 13
	ai_move,	 -0.012, NULL,	// frame 14
	ai_move,	 -0.017, NULL,	// frame 15
};
mmove_t	thug2_move_death1 = {FRAME_death1_01, FRAME_death1_16, thug2_frames_death1, AI_EndDeath};

mframe_t	thug2_frames_death2[] = 
{
	ai_move,	 -1.257, NULL,	// frame 0
	ai_move,	 -9.279, NULL,	// frame 1
	ai_move,	 -9.694, NULL,	// frame 2
	ai_move,	 -3.081, NULL,	// frame 3
	ai_move,	 -4.356, NULL,	// frame 4
	ai_move,	 -7.858, NULL,	// frame 5
	ai_move,	 -9.416, NULL,	// frame 6
	ai_move,	 -7.609, NULL,	// frame 7
	ai_move,	 -0.727, NULL,	// frame 8
	ai_move,	  0.463, NULL,	// frame 9
	ai_move,	 -0.095, NULL,	// frame 10
	ai_move,	  0.390, NULL,	// frame 11
	ai_move,	 -0.166, NULL,	// frame 12
	ai_move,	 -0.040, NULL,	// frame 13
	ai_move,	 -0.014, NULL,	// frame 14
	ai_move,	  0.008, NULL,	// frame 15
	ai_move,	 -0.013, NULL,	// frame 16
	ai_move,	  0.018, NULL,	// frame 17
	ai_move,	  0.008, NULL,	// frame 18
};
mmove_t	thug2_move_death2 = {FRAME_death2_01, FRAME_death2_19, thug2_frames_death2, AI_EndDeath};

mframe_t	thug2_frames_death3[] = 
{
	ai_move,	 -2.603, NULL,	// frame 0
	ai_move,	-13.458, NULL,	// frame 1
	ai_move,	 -4.258, NULL,	// frame 2
	ai_move,	 -2.817, NULL,	// frame 3
	ai_move,	 -6.518, NULL,	// frame 4
	ai_move,	-13.554, NULL,	// frame 5
	ai_move,	 -4.266, NULL,	// frame 6
	ai_move,	 -2.536, NULL,	// frame 7
	ai_move,	 -8.930, NULL,	// frame 8
	ai_move,	 -3.249, NULL,	// frame 9
	ai_move,	 -0.212, NULL,	// frame 10
	ai_move,	  0.674, NULL,	// frame 11
	ai_move,	 -0.340, NULL,	// frame 12
	ai_move,	 -0.129, NULL,	// frame 13
};
mmove_t	thug2_move_death3 = {FRAME_death3_01, FRAME_death3_14, thug2_frames_death3, AI_EndDeath};

mframe_t	thug2_frames_death4[] = 
{
	ai_move,	 -1.292, NULL,	// frame 0
	ai_move,	 -0.037, NULL,	// frame 1
	ai_move,	 -0.620, NULL,	// frame 2
	ai_move,	 -1.143, NULL,	// frame 3
	ai_move,	 -3.476, NULL,	// frame 4
	ai_move,	  1.975, NULL,	// frame 5
	ai_move,	  1.296, NULL,	// frame 6
	ai_move,	 -0.489, NULL,	// frame 7
	ai_move,	 -0.306, NULL,	// frame 8
	ai_move,	  0.042, NULL,	// frame 9
	ai_move,	 -0.163, NULL,	// frame 10
	ai_move,	 -0.039, NULL,	// frame 11
	ai_move,	  0.039, NULL,	// frame 12
	ai_move,	 -0.007, NULL,	// frame 13
	ai_move,	 -0.006, NULL,	// frame 14
};
mmove_t	thug2_move_death4 = {FRAME_death4_01, FRAME_death4_15, thug2_frames_death4, AI_EndDeath};

mframe_t	thug2_frames_death5[] = 
{
	ai_move,	 -0.167, NULL,	// frame 0
	ai_move,	 -0.716, NULL,	// frame 1
	ai_move,	 -1.767, NULL,	// frame 2
	ai_move,	 -0.731, NULL,	// frame 3
	ai_move,	 -4.556, NULL,	// frame 4
	ai_move,	 -1.844, NULL,	// frame 5
	ai_move,	  1.790, NULL,	// frame 6
	ai_move,	  2.718, NULL,	// frame 7
	ai_move,	  4.071, NULL,	// frame 8
	ai_move,	  6.192, NULL,	// frame 9
	ai_move,	  9.945, NULL,	// frame 10
	ai_move,	  2.529, NULL,	// frame 11
	ai_move,	 -0.830, NULL,	// frame 12
	ai_move,	 -0.498, NULL,	// frame 13
	ai_move,	  0.204, NULL,	// frame 14
	ai_move,	  0.162, NULL,	// frame 15
	ai_move,	 -0.104, NULL,	// frame 16
	ai_move,	 -0.005, NULL,	// frame 17
};
mmove_t	thug2_move_death5 = {FRAME_death5_01, FRAME_death5_18, thug2_frames_death5, AI_EndDeath};

