// ep_log.h

#define	NUM_SKIDROW_PLAYER_LOG	13
extern	player_log_t ep_skidrow_player_log[]; 

#define	NUM_PV_PLAYER_LOG 8
extern	player_log_t ep_pv_player_log[];

#define	NUM_SY_PLAYER_LOG 9
extern	player_log_t ep_sy_player_log[];

#define	NUM_TY_PLAYER_LOG 4
extern	player_log_t ep_ty_player_log[];

#define	NUM_ST_PLAYER_LOG 12
extern	player_log_t ep_st_player_log[];

#define	NUM_RC_PLAYER_LOG 6
extern	player_log_t ep_rc_player_log[];
