
mframe_t	runt_frames_amb_stand[] = 
{
	ai_stand,	  0.000, runt_talk_think,	// frame 0
	ai_stand,	  0.000, runt_talk_think,	// frame 1
	ai_stand,	  0.000, runt_talk_think,	// frame 2
	ai_stand,	  0.000, runt_talk_think,	// frame 3
	ai_stand,	  0.000, runt_talk_think,	// frame 4
	ai_stand,	  0.000, runt_talk_think,	// frame 5
	ai_stand,	  0.000, runt_talk_think,	// frame 6
	ai_stand,	  0.000, runt_talk_think,	// frame 7
	ai_stand,	  0.000, runt_talk_think,	// frame 8
	ai_stand,	  0.000, runt_talk_think,	// frame 9
	ai_stand,	  0.000, runt_talk_think,	// frame 10
	ai_stand,	  0.000, runt_talk_think,	// frame 11
	ai_stand,	  0.000, runt_talk_think,	// frame 12
	ai_stand,	  0.000, runt_talk_think,	// frame 13
	ai_stand,	  0.000, runt_talk_think,	// frame 14
	ai_stand,	  0.000, runt_talk_think,	// frame 15
	ai_stand,	  0.000, runt_talk_think,	// frame 16
	ai_stand,	  0.000, runt_talk_think,	// frame 17
	ai_stand,	  0.000, runt_talk_think,	// frame 18
	ai_stand,	  0.000, runt_talk_think,	// frame 19
};
mmove_t	runt_move_amb_stand = {FRAME_amb_stand_01, FRAME_amb_stand_20, runt_frames_amb_stand, runt_end_stand};

mframe_t	runt_frames_talk1[] = 
{
	ai_stand,	  0.000, runt_talk_think,	// frame 0
	ai_stand,	  0.000, runt_talk_think,	// frame 1
	ai_stand,	  0.000, runt_talk_think,	// frame 2
	ai_stand,	  0.000, runt_talk_think,	// frame 3
	ai_stand,	  0.000, runt_talk_think,	// frame 4
	ai_stand,	  0.000, runt_talk_think,	// frame 5
	ai_stand,	  0.000, runt_talk_think,	// frame 6
	ai_stand,	  0.000, runt_talk_think,	// frame 7
	ai_stand,	  0.000, runt_talk_think,	// frame 8
	ai_stand,	  0.000, runt_talk_think,	// frame 9
	ai_stand,	  0.000, runt_talk_think,	// frame 10
	ai_stand,	  0.000, runt_talk_think,	// frame 11
	ai_stand,	  0.000, runt_talk_think,	// frame 12
	ai_stand,	  0.000, runt_talk_think,	// frame 13
};
mmove_t	runt_move_talk1 = {FRAME_talk1_01, FRAME_talk1_14, runt_frames_talk1, runt_end_stand};

mframe_t	runt_frames_talk2[] = 
{
	ai_stand,	  0.000, runt_talk_think,	// frame 0
	ai_stand,	  0.000, runt_talk_think,	// frame 1
	ai_stand,	  0.000, runt_talk_think,	// frame 2
	ai_stand,	  0.000, runt_talk_think,	// frame 3
	ai_stand,	  0.000, runt_talk_think,	// frame 4
	ai_stand,	  0.000, runt_talk_think,	// frame 5
	ai_stand,	  0.000, runt_talk_think,	// frame 6
	ai_stand,	  0.000, runt_talk_think,	// frame 7
	ai_stand,	  0.000, runt_talk_think,	// frame 8
	ai_stand,	  0.000, runt_talk_think,	// frame 9
	ai_stand,	  0.000, runt_talk_think,	// frame 10
	ai_stand,	  0.000, runt_talk_think,	// frame 11
	ai_stand,	  0.000, runt_talk_think,	// frame 12
	ai_stand,	  0.000, runt_talk_think,	// frame 13
	ai_stand,	  0.000, runt_talk_think,	// frame 14
	ai_stand,	  0.000, runt_talk_think,	// frame 15
	ai_stand,	  0.000, runt_talk_think,	// frame 16
	ai_stand,	  0.000, runt_talk_think,	// frame 17
	ai_stand,	  0.000, runt_talk_think,	// frame 18
	ai_stand,	  0.000, runt_talk_think,	// frame 19
	ai_stand,	  0.000, runt_talk_think,	// frame 20
	ai_stand,	  0.000, runt_talk_think,	// frame 21
};
mmove_t	runt_move_talk2 = {FRAME_talk2_01, FRAME_talk2_22, runt_frames_talk2, runt_end_stand};

mframe_t	runt_frames_talk3[] = 
{
	ai_stand,	  0.000,  runt_talk_think,	// frame 0
	ai_stand,	  0.000,  runt_talk_think,	// frame 1
	ai_stand,	  0.000,  runt_talk_think,	// frame 2
	ai_stand,	  0.000,  runt_talk_think,	// frame 3
	ai_stand,	  0.000,  runt_talk_think,	// frame 4
	ai_stand,	  0.000,  runt_talk_think,	// frame 5
	ai_stand,	  0.000,  runt_talk_think,	// frame 6
	ai_stand,	  0.000,  runt_talk_think,	// frame 7
	ai_stand,	  0.000,  runt_talk_think,	// frame 8
	ai_stand,	  0.000,  runt_talk_think,	// frame 9
	ai_stand,	  0.000,  runt_talk_think,	// frame 10
	ai_stand,	  0.000,  runt_talk_think,	// frame 11
	ai_stand,	  0.000,  runt_talk_think,	// frame 12
	ai_stand,	  0.000,  runt_talk_think,	// frame 13
};
mmove_t	runt_move_talk3 = {FRAME_talk3_01, FRAME_talk3_14, runt_frames_talk3, runt_end_stand};

mframe_t	runt_frames_talk4[] = 
{
	ai_stand,	  0.000, runt_talk_think,	// frame 0
	ai_stand,	  0.000, runt_talk_think,	// frame 1
	ai_stand,	  0.000, runt_talk_think,	// frame 2
	ai_stand,	  0.000, runt_talk_think,	// frame 3
	ai_stand,	  0.000, runt_talk_think,	// frame 4
	ai_stand,	  0.000, runt_talk_think,	// frame 5
	ai_stand,	  0.000, runt_talk_think,	// frame 6
	ai_stand,	  0.000, runt_talk_think,	// frame 7
	ai_stand,	  0.000, runt_talk_think,	// frame 8
	ai_stand,	  0.000, runt_talk_think,	// frame 9
	ai_stand,	  0.000, runt_talk_think,	// frame 10
	ai_stand,	  0.000, runt_talk_think,	// frame 11
	ai_stand,	  0.000, runt_talk_think,	// frame 12
	ai_stand,	  0.000, runt_talk_think,	// frame 13
	ai_stand,	  0.000, runt_talk_think,	// frame 14
	ai_stand,	  0.000, runt_talk_think,	// frame 15
	ai_stand,	  0.000, runt_talk_think,	// frame 16
	ai_stand,	  0.000, runt_talk_think,	// frame 17
	ai_stand,	  0.000, runt_talk_think,	// frame 18
	ai_stand,	  0.000, runt_talk_think,	// frame 19
	ai_stand,	  0.000, runt_talk_think,	// frame 20
	ai_stand,	  0.000, runt_talk_think,	// frame 21
	ai_stand,	  0.000, runt_talk_think,	// frame 22
	
};
mmove_t	runt_move_talk4 = {FRAME_talk4_01, FRAME_talk4_23, runt_frames_talk4, runt_end_stand};

mframe_t	runt_frames_talk5[] = 
{
	ai_stand,	  0.000, runt_talk_think,	// frame 0
	ai_stand,	  0.000, runt_talk_think,	// frame 1
	ai_stand,	  0.000, runt_talk_think,	// frame 2
	ai_stand,	  0.000, runt_talk_think,	// frame 3
	ai_stand,	  0.000, runt_talk_think,	// frame 4
	ai_stand,	  0.000, runt_talk_think,	// frame 5
	ai_stand,	  0.000, runt_talk_think,	// frame 6
	ai_stand,	  0.000, runt_talk_think,	// frame 7
	ai_stand,	  0.000, runt_talk_think,	// frame 8
	ai_stand,	  0.000, runt_talk_think,	// frame 9
	ai_stand,	  0.000, runt_talk_think,	// frame 10
	ai_stand,	  0.000, runt_talk_think,	// frame 11
	ai_stand,	  0.000, runt_talk_think,	// frame 12
	ai_stand,	  0.000, runt_talk_think,	// frame 13
	ai_stand,	  0.000, runt_talk_think,	// frame 14
	ai_stand,	  0.000, runt_talk_think,	// frame 15
	ai_stand,	  0.000, runt_talk_think,	// frame 16
	ai_stand,	  0.000, runt_talk_think,	// frame 17
	ai_stand,	  0.000, runt_talk_think,	// frame 18
	ai_stand,	  0.000, runt_talk_think,	// frame 19
	ai_stand,	  0.000, runt_talk_think,	// frame 20
	ai_stand,	  0.000, runt_talk_think,	// frame 21
	ai_stand,	  0.000, runt_talk_think,	// frame 22
};
mmove_t	runt_move_talk5 = {FRAME_talk5_01, FRAME_talk5_23, runt_frames_talk5, runt_end_stand};

mframe_t	runt_frames_talk6[] = 
{
	ai_stand,	  0.000, runt_talk_think,	// frame 0
	ai_stand,	  0.000, runt_talk_think,	// frame 1
	ai_stand,	  0.000, runt_talk_think,	// frame 2
	ai_stand,	  0.000, runt_talk_think,	// frame 3
	ai_stand,	  0.000, runt_talk_think,	// frame 4
	ai_stand,	  0.000, runt_talk_think,	// frame 5
	ai_stand,	  0.000, runt_talk_think,	// frame 6
	ai_stand,	  0.000, runt_talk_think,	// frame 7
	ai_stand,	  0.000, runt_talk_think,	// frame 8
	ai_stand,	  0.000, runt_talk_think,	// frame 9
	ai_stand,	  0.000, runt_talk_think,	// frame 10
	ai_stand,	  0.000, runt_talk_think,	// frame 11
	ai_stand,	  0.000, runt_talk_think,	// frame 12
	ai_stand,	  0.000, runt_talk_think,	// frame 13
	ai_stand,	  0.000, runt_talk_think,	// frame 14
	ai_stand,	  0.000, runt_talk_think,	// frame 15
	ai_stand,	  0.000, runt_talk_think,	// frame 16
	ai_stand,	  0.000, runt_talk_think,	// frame 17
	ai_stand,	  0.000, runt_talk_think,	// frame 18
	ai_stand,	  0.000, runt_talk_think,	// frame 19
	ai_stand,	  0.000, runt_talk_think,	// frame 20
	ai_stand,	  0.000, runt_talk_think,	// frame 21
	
};
mmove_t	runt_move_talk6 = {FRAME_talk6_01, FRAME_talk6_22, runt_frames_talk6, runt_end_stand};

mframe_t	runt_frames_talk7[] = 
{
	ai_stand,	  0.000,  runt_talk_think,	// frame 0
	ai_stand,	  0.000,  runt_talk_think,	// frame 1
	ai_stand,	  0.000,  runt_talk_think,	// frame 2
	ai_stand,	  0.000,  runt_talk_think,	// frame 3
	ai_stand,	  0.000,  runt_talk_think,	// frame 4
	ai_stand,	  0.000,  runt_talk_think,	// frame 5
	ai_stand,	  0.000,  runt_talk_think,	// frame 6
	ai_stand,	  0.000,  runt_talk_think,	// frame 7
	ai_stand,	  0.000,  runt_talk_think,	// frame 8
	ai_stand,	  0.000,  runt_talk_think,	// frame 9
	ai_stand,	  0.000,  runt_talk_think,	// frame 10
	ai_stand,	  0.000,  runt_talk_think,	// frame 11
	ai_stand,	  0.000,  runt_talk_think,	// frame 12
	ai_stand,	  0.000,  runt_talk_think,	// frame 13
	ai_stand,	  0.000,  runt_talk_think,	// frame 14
	ai_stand,	  0.000,  runt_talk_think,	// frame 15
	ai_stand,	  0.000,  runt_talk_think,	// frame 16
	ai_stand,	  0.000,  runt_talk_think,	// frame 17
	ai_stand,	  0.000,  runt_talk_think,	// frame 18
	ai_stand,	  0.000,  runt_talk_think,	// frame 19
	ai_stand,	  0.000,  runt_talk_think,	// frame 20
	ai_stand,	  0.000,  runt_talk_think,	// frame 21
	ai_stand,	  0.000,  runt_talk_think,	// frame 22
	ai_stand,	  0.000,  runt_talk_think,	// frame 23
	ai_stand,	  0.000,  runt_talk_think,	// frame 24
	ai_stand,	  0.000,  runt_talk_think,	// frame 25
	ai_stand,	  0.000,  runt_talk_think,	// frame 26
	ai_stand,	  0.000,  runt_talk_think,	// frame 27
	ai_stand,	  0.000,  runt_talk_think,	// frame 28
	ai_stand,	  0.000,  runt_talk_think,	// frame 29
	ai_stand,	  0.000,  runt_talk_think,	// frame 30
	ai_stand,	  0.000,  runt_talk_think,	// frame 31
	ai_stand,	  0.000,  runt_talk_think,	// frame 32
	ai_stand,	  0.000,  runt_talk_think,	// frame 33
	ai_stand,	  0.000,  runt_talk_think,	// frame 34
	ai_stand,	  0.000,  runt_talk_think,	// frame 35
};
mmove_t	runt_move_talk7 = {FRAME_talk7_01, FRAME_talk7_36, runt_frames_talk7, runt_end_stand};

mframe_t	runt_frames_talk8[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
	ai_stand,	  0.000, NULL,	// frame 9
	ai_stand,	  0.000, NULL,	// frame 10
	ai_stand,	  0.000, NULL,	// frame 11
	ai_stand,	  0.000, NULL,	// frame 12
	ai_stand,	  0.000, NULL,	// frame 13
	ai_stand,	  0.000, NULL,	// frame 14
	ai_stand,	  0.000, NULL,	// frame 15
	ai_stand,	  0.000, NULL,	// frame 16
	ai_stand,	  0.000, NULL,	// frame 17
	ai_stand,	  0.000, NULL,	// frame 18
	ai_stand,	  0.000, NULL,	// frame 19
	ai_stand,	  0.000, NULL,	// frame 20
	ai_stand,	  0.000, NULL,	// frame 21
	ai_stand,	  0.000, NULL,	// frame 22
	ai_stand,	  0.000, NULL,	// frame 23
	ai_stand,	  0.000, NULL,	// frame 24
	ai_stand,	  0.000, NULL,	// frame 25
	ai_stand,	  0.000, NULL,	// frame 26
	ai_stand,	  0.000, NULL,	// frame 27
	ai_stand,	  0.000, NULL,	// frame 28
	ai_stand,	  0.000, NULL,	// frame 29
	ai_stand,	  0.000, NULL,	// frame 30
	ai_stand,	  0.000, NULL,	// frame 31
	ai_stand,	  0.000, NULL,	// frame 32
	ai_stand,	  0.000, NULL,	// frame 33
};
mmove_t	runt_move_talk8 = {FRAME_talk8_01, FRAME_talk8_34, runt_frames_talk8, runt_end_stand};


mframe_t	runt_frames_pull_guns[] = 
{
	 ai_turn,	  0.000, NULL,	// frame 0
	 ai_turn,	  0.000, NULL,	// frame 1
	 ai_turn,	  0.000, runt_show_guns,	// frame 2
	 ai_turn,	  0.000, NULL,	// frame 3
	 ai_turn,	  0.000, NULL,	// frame 4
	 ai_turn,	  0.000, NULL,	// frame 5
	 ai_turn,	  0.000, NULL,	// frame 6
	 ai_turn,	  0.000, NULL,	// frame 7
};
mmove_t	runt_move_pull_guns = {FRAME_pull_guns_01, FRAME_pull_guns_08, runt_frames_pull_guns, AI_EndAttack};

mframe_t	runt_frames_shoot[] = 
{
	ai_turn,	  0.000, NULL,	// frame 0
	ai_turn,	  0.000, runt_left_fire,	// frame 1
	ai_turn,	  0.000, NULL,	// frame 2
	ai_turn,	  0.000, runt_right_fire,	// frame 3
	ai_turn,	  0.000, NULL,	// frame 4
	ai_turn,	  0.000, runt_left_fire,	// frame 5
	ai_turn,	  0.000, NULL,	// frame 6
	ai_turn,	  0.000, runt_right_fire,	// frame 7
};
mmove_t	runt_move_shoot = {FRAME_shoot_01, FRAME_shoot_08, runt_frames_shoot, AI_EndAttack};

mframe_t	runt_frames_reload[] = 
{
	 ai_turn,	  0.000, NULL,	// frame 0
	 ai_turn,	  0.000, NULL,	// frame 1
	 ai_turn,	  0.000, NULL,	// frame 2
	 ai_turn,	  0.000, NULL,	// frame 3
	 ai_turn,	  0.000, NULL,	// frame 4
	 ai_turn,	  0.000, NULL,	// frame 5
	 ai_turn,	  0.000, NULL,	// frame 6
	 ai_turn,	  0.000, NULL,	// frame 7
	 ai_turn,	  0.000, NULL,	// frame 8
	 ai_turn,	  0.000, NULL,	// frame 9
	 ai_turn,	  0.000, NULL,	// frame 10
	 ai_turn,	  0.000, NULL,	// frame 11
	 ai_turn,	  0.000, NULL,	// frame 12
	 ai_turn,	  0.000, NULL,	// frame 13
	 ai_turn,	  0.000, NULL,	// frame 14
	 ai_turn,	  0.000, NULL,	// frame 15
	 ai_turn,	  0.000, NULL,	// frame 16
};
mmove_t	runt_move_reload = {FRAME_reload_01, FRAME_reload_17, runt_frames_reload, AI_EndAttack};

mframe_t	runt_frames_kneel[] = 
{
	ai_charge,	  0.0, NULL,	// frame 0
	ai_charge,	  0.0, NULL,	// frame 1
	ai_charge,	  0.0, runt_show_guns,	// frame 2
	ai_charge,	  0.0, NULL,	// frame 3
	ai_charge,	  0.0, NULL,	// frame 4
	ai_charge,	  0.0, NULL,	// frame 5
	ai_charge,	  0.0, NULL,	// frame 6
	ai_charge,	  0.0, NULL,	// frame 7
};
mmove_t	runt_move_kneel = {FRAME_kneel_01, FRAME_kneel_08, runt_frames_kneel, runt_kneel_shoot};

mframe_t	runt_frames_kneel_up[] = 
{
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 0
};
mmove_t	runt_move_kneel_up = {FRAME_kneel_08, FRAME_kneel_01, runt_frames_kneel_up, AI_EndAttack};

mframe_t	runt_frames_knl_shoot[] = 
{
	 ai_charge,	  0.000, runt_right_fire,	// frame 0
	 ai_charge,	  0.000, NULL,	// frame 1
	 ai_charge,	  0.000, NULL,	// frame 2
	 ai_charge,	  0.000, NULL,	// frame 3
	 ai_charge,	  0.000, NULL,	// frame 4
	 ai_charge,	  0.000, runt_left_fire,	// frame 5
	 ai_charge,	  0.000, NULL,	// frame 6
	 ai_charge,	  0.000, NULL,	// frame 7
	 ai_charge,	  0.000, NULL,	// frame 8
	 ai_charge,	  0.000, NULL,	// frame 9
};
mmove_t	runt_move_knl_shoot = {FRAME_knl_shoot_01, FRAME_knl_shoot_10, runt_frames_knl_shoot, runt_end_kneel_attack};

mframe_t	runt_frames_melee1[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee,	// frame 5
	ai_turn2,	  0.000, runt_melee_bail,	// frame 6
	ai_turn2,	  0.000, runt_melee_bail,	// frame 7
	ai_turn2,	  0.000, runt_melee_bail,	// frame 8
	ai_turn2,	  0.000, runt_melee,	// frame 9
	ai_turn2,	  0.000, NULL,	// frame 10
	ai_turn2,	  0.000, NULL,	// frame 11
	ai_turn2,	  0.000, NULL,	// frame 12
};
mmove_t	runt_move_melee1 = {FRAME_melee1_01, FRAME_melee1_13, runt_frames_melee1, AI_EndAttack};

mframe_t	runt_frames_melee2[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee_bail,	// frame 6
	ai_turn2,	  0.000, runt_melee_bail,	// frame 7
	ai_turn2,	  0.000, runt_melee,	// frame 8
	ai_turn2,	  0.000, runt_melee_bail,	// frame 9
	ai_turn2,	  0.000, runt_melee_bail,	// frame 10
	ai_turn2,	  0.000, runt_melee_bail,	// frame 11
	ai_turn2,	  0.000, runt_melee,	// frame 12
	ai_turn2,	  0.000, NULL,	// frame 13
	ai_turn2,	  0.000, NULL,	// frame 14
	ai_turn2,	  0.000, NULL,	// frame 15
	ai_turn2,	  0.000, NULL,	// frame 16
	ai_turn2,	  0.000, NULL,	// frame 17
};
mmove_t	runt_move_melee2 = {FRAME_melee2_01, FRAME_melee2_18, runt_frames_melee2, AI_EndAttack};

mframe_t	runt_frames_melee3[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee,	// frame 6
	ai_turn2,	  0.000, runt_melee_bail,	// frame 7
	ai_turn2,	  0.000, runt_melee_bail,	// frame 8
	ai_turn2,	  0.000, runt_melee_bail,	// frame 9
	ai_turn2,	  0.000, runt_melee_bail,	// frame 10
	ai_turn2,	  0.000, runt_melee,	// frame 11
	ai_turn2,	  0.000, NULL,	// frame 12
	ai_turn2,	  0.000, NULL,	// frame 13
	ai_turn2,	  0.000, NULL,	// frame 14
	ai_turn2,	  0.000, NULL,	// frame 15
	ai_turn2,	  0.000, NULL,	// frame 16
	ai_turn2,	  0.000, NULL,	// frame 17
	ai_turn2,	  0.000, NULL,	// frame 18
};
mmove_t	runt_move_melee3 = {FRAME_melee3_01, FRAME_melee3_19, runt_frames_melee3, AI_EndAttack};

mframe_t	runt_frames_melee4[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee,	// frame 6
	ai_turn2,	  0.000, NULL,	// frame 7
};
mmove_t	runt_move_melee4 = {FRAME_melee4_01, FRAME_melee4_08, runt_frames_melee4, AI_EndAttack};

mframe_t	runt_frames_melee5[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee_bail,	// frame 6
	ai_turn2,	  0.000, runt_melee,	// frame 7
	ai_turn2,	  0.000, runt_melee_bail,	// frame 8
	ai_turn2,	  0.000, runt_melee_bail,	// frame 9
	ai_turn2,	  0.000, runt_melee,	// frame 10
	ai_turn2,	  0.000, NULL,	// frame 11
	ai_turn2,	  0.000, NULL,	// frame 12
};
mmove_t	runt_move_melee5 = {FRAME_melee5_01, FRAME_melee5_13, runt_frames_melee5, AI_EndAttack};

mframe_t	runt_frames_melee6[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee_bail,	// frame 6
	ai_turn2,	  0.000, runt_melee,	// frame 7
	ai_turn2,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_melee6 = {FRAME_melee6_01, FRAME_melee6_09, runt_frames_melee6, AI_EndAttack};

// this is a cowering move
mframe_t	runt_frames_melee_amb1[] = 
{
	NULL,	  0.000, runt_evade_checkadjust,	// frame 0
	NULL,	  0.000, runt_evade_checkadjust,	// frame 1
	NULL,	  0.000, runt_evade_checkadjust,	// frame 2
	NULL,	  0.000, runt_evade_checkadjust,	// frame 3
	NULL,	  0.000, runt_evade_checkadjust,	// frame 4
	NULL,	  0.000, runt_evade_checkadjust,	// frame 5
	NULL,	  0.000, runt_evade_checkadjust,	// frame 6
	NULL,	  0.000, runt_evade_checkadjust,	// frame 7
	NULL,	  0.000, runt_evade_checkadjust,	// frame 8
	NULL,	  0.000, runt_evade_checkadjust,	// frame 9
	NULL,	  0.000, runt_evade_checkadjust,	// frame 10
	NULL,	  0.000, runt_evade_checkadjust,	// frame 11
	NULL,	  0.000, runt_evade_checkadjust,	// frame 12
	NULL,	  0.000, runt_evade_checkadjust,	// frame 13
	NULL,	  0.000, runt_evade_checkadjust,	// frame 14
	NULL,	  0.000, runt_evade_checkadjust,	// frame 15
	NULL,	  0.000, runt_evade_checkadjust,	// frame 16
};
mmove_t	runt_move_melee_amb1 = {FRAME_melee_amb1_01, FRAME_melee_amb1_17, runt_frames_melee_amb1, AI_CheckEvade};

mframe_t	runt_frames_low_melee1[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee_bail,	// frame 6
	ai_turn2,	  0.000, runt_melee,	// frame 7
	ai_turn2,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_low_melee1 = {FRAME_low_melee1_01, FRAME_low_melee1_09, runt_frames_low_melee1, AI_EndAttack};

mframe_t	runt_frames_low_melee2[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee,	// frame 5
};
mmove_t	runt_move_low_melee2 = {FRAME_low_melee2_01, FRAME_low_melee2_06, runt_frames_low_melee2, AI_EndAttack};

mframe_t	runt_frames_low_melee3[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee,	// frame 4
	ai_turn2,	  0.000, NULL,	// frame 5
};
mmove_t	runt_move_low_melee3 = {FRAME_low_melee3_01, FRAME_low_melee3_06, runt_frames_low_melee3, AI_EndAttack};

mframe_t	runt_frames_low_melee4[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee,	// frame 6
	ai_turn2,	  0.000, NULL,	// frame 7
};
mmove_t	runt_move_low_melee4 = {FRAME_low_melee4_01, FRAME_low_melee4_08, runt_frames_low_melee4, AI_EndAttack};

mframe_t	runt_frames_low_melee5[] = 
{
	ai_turn2,	  0.000, runt_melee_bail,	// frame 0
	ai_turn2,	  0.000, runt_melee_bail,	// frame 1
	ai_turn2,	  0.000, runt_melee_bail,	// frame 2
	ai_turn2,	  0.000, runt_melee_bail,	// frame 3
	ai_turn2,	  0.000, runt_melee_bail,	// frame 4
	ai_turn2,	  0.000, runt_melee_bail,	// frame 5
	ai_turn2,	  0.000, runt_melee_bail,	// frame 6
	ai_turn2,	  0.000, runt_melee_bail,	// frame 7
	ai_turn2,	  0.000, runt_melee,	// frame 8
	ai_turn2,	  0.000, NULL,	// frame 9
	ai_turn2,	  0.000, NULL,	// frame 10
	ai_turn2,	  0.000, NULL,	// frame 11
	ai_turn2,	  0.000, NULL,	// frame 12
	ai_turn2,	  0.000, NULL,	// frame 13
	ai_turn2,	  0.000, NULL,	// frame 14
};
mmove_t	runt_move_low_melee5 = {FRAME_low_melee5_01, FRAME_low_melee5_15, runt_frames_low_melee5, AI_EndAttack};

// not using this for now
mframe_t	runt_frames_lw_melee_a[] = 
{
	NULL,	  0.000, runt_evade_checkadjust,	// frame 0
	NULL,	  0.000, runt_evade_checkadjust,	// frame 1
	NULL,	  0.000, runt_evade_checkadjust,	// frame 2
	NULL,	  0.000, runt_evade_checkadjust,	// frame 3
	NULL,	  0.000, runt_evade_checkadjust,	// frame 4
	NULL,	  0.000, runt_evade_checkadjust,	// frame 5
	NULL,	  0.000, runt_evade_checkadjust,	// frame 6
	NULL,	  0.000, runt_evade_checkadjust,	// frame 7
	NULL,	  0.000, runt_evade_checkadjust,	// frame 8
	NULL,	  0.000, runt_evade_checkadjust,	// frame 9
	NULL,	  0.000, runt_evade_checkadjust,	// frame 10
	NULL,	  0.000, runt_evade_checkadjust,	// frame 11
	NULL,	  0.000, runt_evade_checkadjust,	// frame 12
	NULL,	  0.000, runt_evade_checkadjust,	// frame 13
};
mmove_t	runt_move_lw_melee_a = {FRAME_lw_melee_a_01, FRAME_lw_melee_a_14, runt_frames_lw_melee_a, AI_CheckEvade};

mframe_t	runt_frames_jump[] = 
{
	// ai_stand,	  0.000, NULL,	// frame 0
	// ai_stand,	  0.000, NULL,	// frame 1
	// ai_stand,	  0.000, NULL,	// frame 2
	// ai_stand,	  0.000, NULL,	// frame 3
	// ai_stand,	  0.000, NULL,	// frame 4

	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, AI_CheckStillInair,	// frame 7
	NULL,	  0.000, NULL,	// frame 8

	// ai_stand,	  0.000, NULL,	// frame 9
	// ai_stand,	  0.000, NULL,	// frame 10
	// ai_stand,	  0.000, NULL,	// frame 11
	// ai_stand,	  0.000, NULL,	// frame 12
	// ai_stand,	  0.000, NULL,	// frame 13
	// ai_stand,	  0.000, NULL,	// frame 14
	// ai_stand,	  0.000, NULL,	// frame 15
	// ai_stand,	  0.000, NULL,	// frame 16
};
mmove_t	runt_move_jump = {FRAME_jump_05, FRAME_jump_08, runt_frames_jump, AI_EndJump};

mframe_t	runt_frames_pstl_jump[] = 
{
	// ai_stand,	  0.000, NULL,	// frame 0
	// ai_stand,	  0.000, NULL,	// frame 1
	// ai_stand,	  0.000, NULL,	// frame 2
	// ai_stand,	  0.000, NULL,	// frame 3
	// ai_stand,	  0.000, NULL,	// frame 4
	
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, AI_CheckStillInair,	// frame 7
	NULL,	  0.000, NULL,	// frame 8

	// ai_stand,	  0.000, NULL,	// frame 9
	// ai_stand,	  0.000, NULL,	// frame 10
	// ai_stand,	  0.000, NULL,	// frame 11
	// ai_stand,	  0.000, NULL,	// frame 12
	// ai_stand,	  0.000, NULL,	// frame 13
	// ai_stand,	  0.000, NULL,	// frame 14
};
mmove_t	runt_move_pstl_jump = {FRAME_pstl_jump_05, FRAME_pstl_jump_08, runt_frames_pstl_jump, AI_EndJump};

mframe_t	runt_frames_pain_Rarm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
};
mmove_t	runt_move_pain_Rarm = {FRAME_pain_Rarm_01, FRAME_pain_Rarm_06, runt_frames_pain_Rarm, AI_EndAttack};

mframe_t	runt_frames_pain_Larm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_pain_Larm = {FRAME_pain_Larm_01, FRAME_pain_Larm_09, runt_frames_pain_Larm, AI_EndAttack};

mframe_t	runt_frames_pain_chst[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_pain_chst = {FRAME_pain_chst_01, FRAME_pain_chst_09, runt_frames_pain_chst, AI_EndAttack};

mframe_t	runt_frames_pain_head[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_pain_head = {FRAME_pain_head_01, FRAME_pain_head_09, runt_frames_pain_head, AI_EndAttack};

mframe_t	runt_frames_pain_Rleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
};
mmove_t	runt_move_pain_Rleg = {FRAME_pain_Rleg_01, FRAME_pain_Rleg_11, runt_frames_pain_Rleg, AI_EndAttack};

mframe_t	runt_frames_pain_Lleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_pain_Lleg = {FRAME_pain_Lleg_01, FRAME_pain_Lleg_09, runt_frames_pain_Lleg, AI_EndAttack};

mframe_t	runt_frames_pain_crch[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_pain_crch = {FRAME_pain_crch_01, FRAME_pain_crch_09, runt_frames_pain_crch, AI_EndAttack};

mframe_t	runt_frames_pain_butt[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
};
mmove_t	runt_move_pain_butt = {FRAME_pain_butt_01, FRAME_pain_butt_08, runt_frames_pain_butt, AI_EndAttack};

mframe_t	runt_frames_nw_pain_Rarm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_nw_pain_Rarm = {FRAME_nw_pain_Rarm_01, FRAME_nw_pain_Rarm_09, runt_frames_nw_pain_Rarm, AI_EndAttack};

mframe_t	runt_frames_nw_pain_Larm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
};
mmove_t	runt_move_nw_pain_Larm = {FRAME_nw_pain_Larm_01, FRAME_nw_pain_Larm_10, runt_frames_nw_pain_Larm, AI_EndAttack};

mframe_t	runt_frames_nw_pain_chst[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_nw_pain_chst = {FRAME_nw_pain_chst_01, FRAME_nw_pain_chst_09, runt_frames_nw_pain_chst, AI_EndAttack};

mframe_t	runt_frames_nw_pain_crch[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_nw_pain_crch = {FRAME_nw_pain_crch_01, FRAME_nw_pain_crch_09, runt_frames_nw_pain_crch, AI_EndAttack};

mframe_t	runt_frames_nw_pain_butt[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_nw_pain_butt = {FRAME_nw_pain_butt_01, FRAME_nw_pain_butt_09, runt_frames_nw_pain_butt, AI_EndAttack};

mframe_t	runt_frames_nw_pain_head[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
};
mmove_t	runt_move_nw_pain_head = {FRAME_nw_pain_head_01, FRAME_nw_pain_head_08, runt_frames_nw_pain_head, AI_EndAttack};

mframe_t	runt_frames_nw_pain_Rleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_nw_pain_Rleg = {FRAME_nw_pain_Rleg_01, FRAME_nw_pain_Rleg_09, runt_frames_nw_pain_Rleg, AI_EndAttack};

mframe_t	runt_frames_nw_pain_Lleg[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
};
mmove_t	runt_move_nw_pain_Lleg = {FRAME_nw_pain_Lleg_01, FRAME_nw_pain_Lleg_11, runt_frames_nw_pain_Lleg, AI_EndAttack};

mframe_t	runt_frames_death1[] = 
{
	ai_move,	  0.238, NULL,	// frame 0
	ai_move,	 -1.034, NULL,	// frame 1
	ai_move,	 -9.583, NULL,	// frame 2
	ai_move,	 -0.592, NULL,	// frame 3
	ai_move,	  3.194, NULL,	// frame 4
	ai_move,	  7.565, NULL,	// frame 5
	ai_move,	  3.078, NULL,	// frame 6
	ai_move,	 -2.142, NULL,	// frame 7
	ai_move,	  0.399, NULL,	// frame 8
	ai_move,	  3.574, NULL,	// frame 9
	ai_move,	  2.717, NULL,	// frame 10
	ai_move,	  4.743, NULL,	// frame 11
	ai_move,	  7.929, NULL,	// frame 12
	ai_move,	 10.851, NULL,	// frame 13
	ai_move,	  0.817, NULL,	// frame 14
	ai_move,	 -1.070, NULL,	// frame 15
	ai_move,	 -0.856, NULL,	// frame 16
	ai_move,	  0.396, NULL,	// frame 17
	ai_move,	  0.292, NULL,	// frame 18
	ai_move,	 -0.027, NULL,	// frame 19
	ai_move,	  0.016, NULL,	// frame 20
	ai_move,	  0.010, NULL,	// frame 21
};
mmove_t	runt_move_death1 = {FRAME_death1_01, FRAME_death1_22, runt_frames_death1, AI_EndDeath};

mframe_t	runt_frames_death2[] = 
{
	ai_move,	 -0.144, NULL,	// frame 0
	ai_move,	-15.665, NULL,	// frame 1
	ai_move,	  1.324, NULL,	// frame 2
	ai_move,	  9.216, NULL,	// frame 3
	ai_move,	 17.036, NULL,	// frame 4
	ai_move,	 13.883, NULL,	// frame 5
	ai_move,	 10.773, NULL,	// frame 6
	ai_move,	 -0.456, NULL,	// frame 7
	ai_move,	  2.582, NULL,	// frame 8
	ai_move,	  1.007, NULL,	// frame 9
	ai_move,	  0.337, NULL,	// frame 10
	ai_move,	  0.039, NULL,	// frame 11
	ai_move,	  0.037, NULL,	// frame 12
	ai_move,	  0.003, NULL,	// frame 13
};
mmove_t	runt_move_death2 = {FRAME_death2_01, FRAME_death2_14, runt_frames_death2, AI_EndDeath};

mframe_t	runt_frames_death3[] = 
{
	ai_move,	  0.520, NULL,	// frame 0
	ai_move,	-15.514, NULL,	// frame 1
	ai_move,	 -4.272, NULL,	// frame 2
	ai_move,	  2.028, NULL,	// frame 3
	ai_move,	  7.542, NULL,	// frame 4
	ai_move,	  8.201, NULL,	// frame 5
	ai_move,	  8.360, NULL,	// frame 6
	ai_move,	 19.227, NULL,	// frame 7
	ai_move,	  4.670, NULL,	// frame 8
	ai_move,	  0.909, NULL,	// frame 9
	ai_move,	  9.508, NULL,	// frame 10
	ai_move,	 -0.948, NULL,	// frame 11
	ai_move,	-11.286, NULL,	// frame 12
	ai_move,	  0.418, NULL,	// frame 13
	ai_move,	  0.453, NULL,	// frame 14
	ai_move,	 -0.007, NULL,	// frame 15
	ai_move,	 -0.064, NULL,	// frame 16
	ai_move,	  0.002, NULL,	// frame 17
	ai_move,	  0.001, NULL,	// frame 18
};
mmove_t	runt_move_death3 = {FRAME_death3_01, FRAME_death3_19, runt_frames_death3, AI_EndDeath};

mframe_t	runt_frames_death4[] = 
{
	ai_move,	 -3.228, NULL,	// frame 0
	ai_move,	-12.813, NULL,	// frame 1
	ai_move,	 -9.574, NULL,	// frame 2
	ai_move,	 -3.682, NULL,	// frame 3
	ai_move,	-11.420, NULL,	// frame 4
	ai_move,	 -6.316, NULL,	// frame 5
	ai_move,	 -6.718, NULL,	// frame 6
	ai_move,	 -5.913, NULL,	// frame 7
	ai_move,	  2.085, NULL,	// frame 8
	ai_move,	 -0.542, NULL,	// frame 9
	ai_move,	  1.025, NULL,	// frame 10
	ai_move,	  0.427, NULL,	// frame 11
	ai_move,	 -0.207, NULL,	// frame 12
	ai_move,	 -0.102, NULL,	// frame 13
	ai_move,	  0.076, NULL,	// frame 14
	ai_move,	 -0.002, NULL,	// frame 15
	ai_move,	 -0.018, NULL,	// frame 16
};
mmove_t	runt_move_death4 = {FRAME_death4_01, FRAME_death4_17, runt_frames_death4, AI_EndDeath};

mframe_t	runt_frames_death5[] = 
{
	ai_move,	 -3.046, NULL,	// frame 0
	ai_move,	 -7.635, NULL,	// frame 1
	ai_move,	-17.739, NULL,	// frame 2
	ai_move,	 -7.189, NULL,	// frame 3
	ai_move,	-20.864, NULL,	// frame 4
	ai_move,	 -7.619, NULL,	// frame 5
	ai_move,	 -5.923, NULL,	// frame 6
	ai_move,	 -1.859, NULL,	// frame 7
	ai_move,	  7.043, NULL,	// frame 8
	ai_move,	  4.872, NULL,	// frame 9
	ai_move,	  0.045, NULL,	// frame 10
	ai_move,	  0.610, NULL,	// frame 11
	ai_move,	  0.627, NULL,	// frame 12
	ai_move,	 -0.499, NULL,	// frame 13
	ai_move,	  0.104, NULL,	// frame 14
	ai_move,	  0.000, NULL,	// frame 15
	ai_move,	  0.008, NULL,	// frame 16
	ai_move,	  0.004, NULL,	// frame 17
	ai_move,	 -0.001, NULL,	// frame 18
};
mmove_t	runt_move_death5 = {FRAME_death5_01, FRAME_death5_19, runt_frames_death5, AI_EndDeath};

mframe_t	runt_frames_death6[] = 
{
	ai_move,	  1.086, NULL,	// frame 0
	ai_move,	 -7.158, NULL,	// frame 1
	ai_move,	-19.735, NULL,	// frame 2
	ai_move,	 -4.218, NULL,	// frame 3
	ai_move,	  2.623, NULL,	// frame 4
	ai_move,	 -8.821, NULL,	// frame 5
	ai_move,	 -6.157, NULL,	// frame 6
	ai_move,	-11.324, NULL,	// frame 7
	ai_move,	 -3.710, NULL,	// frame 8
	ai_move,	  1.731, NULL,	// frame 9
	ai_move,	 11.367, NULL,	// frame 10
	ai_move,	  0.115, NULL,	// frame 11
	ai_move,	  0.032, NULL,	// frame 12
	ai_move,	 -0.037, NULL,	// frame 13
	ai_move,	 -0.015, NULL,	// frame 14
	ai_move,	  0.001, NULL,	// frame 15
	ai_move,	 -0.005, NULL,	// frame 16
	ai_move,	  0.002, NULL,	// frame 17
};
mmove_t	runt_move_death6 = {FRAME_death6_01, FRAME_death6_18, runt_frames_death6, AI_EndDeath};

mframe_t	runt_frames_crch_amb_sdt[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
	ai_stand,	  0.000, NULL,	// frame 9
	ai_stand,	  0.000, NULL,	// frame 10
	ai_stand,	  0.000, NULL,	// frame 11
	ai_stand,	  0.000, NULL,	// frame 12
	ai_stand,	  0.000, NULL,	// frame 13
	ai_stand,	  0.000, NULL,	// frame 14
	ai_stand,	  0.000, NULL,	// frame 15
	ai_stand,	  0.000, NULL,	// frame 16
	ai_stand,	  0.000, NULL,	// frame 17
	ai_stand,	  0.000, NULL,	// frame 18
	ai_stand,	  0.000, NULL,	// frame 19
	ai_stand,	  0.000, NULL,	// frame 20
	ai_stand,	  0.000, NULL,	// frame 21
	ai_stand,	  0.000, NULL,	// frame 22
	ai_stand,	  0.000, NULL,	// frame 23
	ai_stand,	  0.000, NULL,	// frame 24
	ai_stand,	  0.000, NULL,	// frame 25
	ai_stand,	  0.000, NULL,	// frame 26
};
mmove_t	runt_move_crch_amb_sdt = {FRAME_crch_amb_sdt_01, FRAME_crch_amb_sdt_27, runt_frames_crch_amb_sdt, NULL};

mframe_t	runt_frames_crch_shoot[] = 
{
	ai_turn,	  0.000, runt_right_fire,	// frame 0
	ai_turn,	  0.000, NULL,	// frame 1
	ai_turn,	  0.000, NULL,	// frame 2
	ai_turn,	  0.000, NULL,	// frame 3
	ai_turn,	  0.000, NULL,	// frame 4
	ai_turn,	  0.000, runt_left_fire,	// frame 5
	ai_turn,	  0.000, NULL,	// frame 6
	ai_turn,	  0.000, NULL,	// frame 7
	ai_turn,	  0.000, NULL,	// frame 8
};
mmove_t	runt_move_crch_shoot = {FRAME_crch_shoot_01, FRAME_crch_shoot_09, runt_frames_crch_shoot, AI_EndAttack};

mframe_t	runt_frames_crouch_walk[] = 
{
	ai_run,	  4.227, NULL,	// frame 0
	ai_run,	  3.913, NULL,	// frame 1
	ai_run,	  4.576, NULL,	// frame 2
	ai_run,	  4.929, NULL,	// frame 3
	ai_run,	  4.588, NULL,	// frame 4
	ai_run,	  3.154, NULL,	// frame 5
	ai_run,	  3.287, NULL,	// frame 6
	ai_run,	  4.085, NULL,	// frame 7
};
mmove_t	runt_move_crouch_walk = {FRAME_crouch_walk_01, FRAME_crouch_walk_08, runt_frames_crouch_walk, NULL};

mframe_t	runt_frames_c_pain_Rarm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
	ai_move,	  0.000, NULL,	// frame 11
};
mmove_t	runt_move_c_pain_Rarm = {FRAME_c_pain_Rarm_01, FRAME_c_pain_Rarm_12, runt_frames_c_pain_Rarm, AI_EndAttack};

mframe_t	runt_frames_c_pain_Larm[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
	ai_move,	  0.000, NULL,	// frame 11
	ai_move,	  0.000, NULL,	// frame 12
};
mmove_t	runt_move_c_pain_Larm = {FRAME_c_pain_Larm_01, FRAME_c_pain_Larm_13, runt_frames_c_pain_Larm, AI_EndAttack};

mframe_t	runt_frames_c_pain_chst[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
};
mmove_t	runt_move_c_pain_chst = {FRAME_c_pain_chst_01, FRAME_c_pain_chst_11, runt_frames_c_pain_chst, AI_EndAttack};

mframe_t	runt_frames_c_pain_head[] = 
{
	ai_move,	  0.000, NULL,	// frame 0
	ai_move,	  0.000, NULL,	// frame 1
	ai_move,	  0.000, NULL,	// frame 2
	ai_move,	  0.000, NULL,	// frame 3
	ai_move,	  0.000, NULL,	// frame 4
	ai_move,	  0.000, NULL,	// frame 5
	ai_move,	  0.000, NULL,	// frame 6
	ai_move,	  0.000, NULL,	// frame 7
	ai_move,	  0.000, NULL,	// frame 8
	ai_move,	  0.000, NULL,	// frame 9
	ai_move,	  0.000, NULL,	// frame 10
	ai_move,	  0.000, NULL,	// frame 11
	ai_move,	  0.000, NULL,	// frame 12
	ai_move,	  0.000, NULL,	// frame 13
	ai_move,	  0.000, NULL,	// frame 14
	ai_move,	  0.000, NULL,	// frame 15
};
mmove_t	runt_move_c_pain_head = {FRAME_c_pain_head_01, FRAME_c_pain_head_16, runt_frames_c_pain_head, AI_EndAttack};

mframe_t	runt_frames_evade[] = 
{
	ai_turn,	  0.581, NULL,	// frame 0
	ai_turn,	  8.219, NULL,	// frame 1
	ai_turn,	  3.057, NULL,	// frame 2
	ai_turn,	-18.376, NULL,	// frame 3
	ai_turn,	 -4.337, NULL,	// frame 4
	ai_turn,	-18.023, NULL,	// frame 5
	ai_turn,	-11.317, NULL,	// frame 6
	ai_turn,	 -6.771, NULL,	// frame 7
	ai_turn,	  3.034, NULL,	// frame 8
// 	ai_turn,	 57.618, NULL,	// frame 9
	ai_turn,	 20.618, NULL,	// frame 9
};
mmove_t	runt_move_evade = {FRAME_evade_01, FRAME_evade_10, runt_frames_evade, runt_evade_amb};

mframe_t	runt_frames_evade_amb[] = 
{
	NULL,	  0.000, runt_evade_checkadjust,	// frame 0
	NULL,	  0.000, runt_evade_checkadjust,	// frame 1
	NULL,	  0.000, runt_evade_checkadjust,	// frame 2
	NULL,	  0.000, runt_evade_checkadjust,	// frame 3
	NULL,	  0.000, runt_evade_checkadjust,	// frame 4
	NULL,	  0.000, runt_evade_checkadjust,	// frame 5
	NULL,	  0.000, runt_evade_checkadjust,	// frame 6
	NULL,	  0.000, runt_evade_checkadjust,	// frame 7
	NULL,	  0.000, runt_evade_checkadjust,	// frame 8
	NULL,	  0.000, runt_evade_checkadjust,	// frame 9
	NULL,	  0.000, runt_evade_checkadjust,	// frame 10
	NULL,	  0.000, runt_evade_checkadjust,	// frame 11
	
};
mmove_t	runt_move_evade_amb = {FRAME_evade_amb_01, FRAME_evade_amb_12, runt_frames_evade_amb, AI_CheckEvade};


mframe_t	runt_frames_evade_stand[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6

	ai_stand,	  0.000, NULL,
	ai_stand,	  0.000, NULL,
	ai_stand,	  0.000, NULL,
	ai_stand,	  0.000, NULL,
	ai_stand,	  0.000, NULL,

};
mmove_t	runt_move_evade_stand = {FRAME_evade_amb_01, FRAME_evade_amb_12, runt_frames_evade_stand, runt_end_stand};



mframe_t	runt_frames_lside_step[] = 
{
	ai_sidestep,	   0.013, NULL,	// frame 0
	ai_sidestep,	   1.814, NULL,	// frame 1
	ai_sidestep,	   8.195, NULL,	// frame 2
	ai_sidestep,	   1.742, NULL,	// frame 3
	ai_sidestep,	  11.579, NULL,	// frame 4
	ai_sidestep,	   9.565, NULL,	// frame 5
	ai_sidestep,	   8.587, NULL,	// frame 6
	ai_sidestep,	   2.062, NULL,	// frame 7
	ai_sidestep,	   1.663, NULL,	// frame 8
	ai_sidestep,	   0.411, NULL,	// frame 9
};
mmove_t	runt_move_lside_step = {FRAME_lside_step_01, FRAME_lside_step_10, runt_frames_lside_step, AI_EndAttack};

mframe_t	runt_frames_rside_step[] = 
{
	ai_sidestep,	    0.008, NULL,	// frame 0
	ai_sidestep,	   -1.045, NULL,	// frame 1
	ai_sidestep,	   -1.978, NULL,	// frame 2
	ai_sidestep,	   -3.345, NULL,	// frame 3
	ai_sidestep,	   -2.344, NULL,	// frame 4
	ai_sidestep,	  -10.970, NULL,	// frame 5
	ai_sidestep,	   -7.659, NULL,	// frame 6
	ai_sidestep,	   -9.143, NULL,	// frame 7
	ai_sidestep,	   -4.204, NULL,	// frame 8
};
mmove_t	runt_move_rside_step = {FRAME_rside_step_01, FRAME_rside_step_09, runt_frames_rside_step, AI_EndAttack};

mframe_t	runt_frames_walk_guns_dn[] = 
{
	ai_run,	  1.235, NULL,	// frame 0
	ai_run,	  7.009, NULL,	// frame 1
	ai_run,	  7.589, NULL,	// frame 2
	ai_run,	 13.206, NULL,	// frame 3
	ai_run,	  3.028, NULL,	// frame 4
	ai_run,	  2.102, NULL,	// frame 5
	ai_run,	 24.908, NULL,	// frame 6
	ai_run,	 11.297, NULL,	// frame 7
	ai_run,	 11.088, NULL,	// frame 8
	ai_run,	  7.711, NULL,	// frame 9
};
mmove_t	runt_move_walk_guns_dn = {FRAME_walk_guns_dn_01, FRAME_walk_guns_dn_10, runt_frames_walk_guns_dn, NULL};

mframe_t	runt_frames_walk_shoot[] = 
{
	ai_turn2,	 	  7.582, runt_left_fire,	// frame 0
	ai_turn2,	 	  2.967, NULL,	// frame 1
	ai_turn2,	 	  7.032, NULL,	// frame 2
	ai_turn2,	 	 12.919, runt_right_fire,	// frame 3
	ai_turn2,	 	  5.230, NULL,	// frame 4
	ai_turn2,	 	  3.191, NULL,	// frame 5
	ai_turn2,	 	 14.270, NULL,	// frame 6
	ai_turn2,	 	 12.124, NULL,	// frame 7
	ai_turn2,	 	  8.824, NULL,	// frame 8
	ai_turn2,	 	 13.341, NULL,	// frame 9
	
};
mmove_t	runt_move_walk_shoot = {FRAME_walk_shoot_01, FRAME_walk_shoot_10, runt_frames_walk_shoot, AI_EndAttack};

mframe_t	runt_frames_run_guns_dn[] = 
{
	ai_run, 13.390, NULL,	// frame 0
	ai_run, 20.672, NULL,	// frame 1
	ai_run, 23.981, NULL,	// frame 2
	ai_run, 21.476, NULL,	// frame 3
	ai_run,  1.388, NULL,	// frame 4
	ai_run, 24.850, NULL,	// frame 5
};
mmove_t	runt_move_run_guns_dn = {FRAME_run_guns_dn_01, FRAME_run_guns_dn_06, runt_frames_run_guns_dn, NULL};

mframe_t	runt_frames_run_shoot[] = 
{
	ai_charge, 2.894, runt_left_fire,	// frame 0
	ai_charge,13.404, NULL,	// frame 1
	ai_charge, 9.943, NULL,	// frame 2
	ai_charge,31.004, runt_right_fire,	// frame 3
	ai_charge,13.367, NULL,	// frame 4
	ai_charge, 9.128, NULL,	// frame 5
};
mmove_t	runt_move_run_shoot = {FRAME_run_shoot_01, FRAME_run_shoot_06, runt_frames_run_shoot, AI_EndAttack};

mframe_t	runt_frames_reverse_run_shoot[] = 
{
	ai_charge, -9.128, NULL,	// frame 5
	ai_charge,-13.367, NULL,	// frame 4
	ai_charge,-31.004, runt_right_fire,	// frame 3
	ai_charge, -9.943, NULL,	// frame 2
	ai_charge,-13.404, NULL,	// frame 1
	ai_charge, -2.894, runt_left_fire,	// frame 0
};
mmove_t	runt_move_reverse_run_shoot = {FRAME_run_shoot_06, FRAME_run_shoot_01, runt_frames_reverse_run_shoot, AI_EndAttack};

mframe_t	runt_frames_run_on_fire[] = 
{
	ai_onfire_run,	  3.788, NULL,	// frame 0
	ai_onfire_run,	 19.318, NULL,	// frame 1
	ai_onfire_run,	  8.519, NULL,	// frame 2
	ai_onfire_run,	 26.090, NULL,	// frame 3
	ai_onfire_run,	 11.733, NULL,	// frame 4
	ai_onfire_run,	  7.604, NULL,	// frame 5
};
mmove_t	runt_move_run_on_fire = {FRAME_run_on_fire_01, FRAME_run_on_fire_06, runt_frames_run_on_fire, NULL};

mframe_t	runt_frames_run_melee[] = 
{
	ai_charge,	16.222, NULL,	// frame 0
	ai_charge,	12.651, NULL,	// frame 1
	ai_charge,	18.236, NULL,	// frame 2
	ai_charge,	12.563, NULL,	// frame 3
	ai_charge,	38.242, runt_melee,	// frame 4
	ai_charge,	 7.863, NULL,	// frame 5
};
mmove_t	runt_move_run_melee = {FRAME_run_melee_01, FRAME_run_melee_06, runt_frames_run_melee, AI_EndAttack};

// oh joy this is backwards again
// Ridah, 5-8-99, they don't seem to be backwards here, changed them back to normal

// Rafael: 03-15-99 thats because you are using the wrong model
mframe_t	runt_frames_lside_run[] = 
{
	ai_sidestep,	  -16.313, runt_firegun_left,	// frame 0
	ai_sidestep,	   -6.614, NULL,	// frame 1
	ai_sidestep,	   -9.217, NULL,	// frame 2
	ai_sidestep,	  -10.424, runt_firegun_left,	// frame 3
	ai_sidestep,	  -11.793, NULL,	// frame 4
	ai_sidestep,	  -16.889, NULL,	// frame 5
};
//mmove_t	runt_move_lside_run = {FRAME_lside_run_01, FRAME_lside_run_06, runt_frames_lside_run, NULL};
mmove_t	runt_move_lside_run = {FRAME_rside_run_01, FRAME_rside_run_06, runt_frames_lside_run, NULL};

mframe_t	runt_frames_rside_run[] = 
{
	ai_sidestep,	  10.051, runt_firegun_right,	// frame 0
	ai_sidestep,	  12.243, NULL,	// frame 1
	ai_sidestep,	   8.393, NULL,	// frame 2
	ai_sidestep,	   8.554, runt_firegun_right,	// frame 3
	ai_sidestep,	  10.702, NULL,	// frame 4
	ai_sidestep,	  10.621, NULL,	// frame 5
};
//mmove_t	runt_move_rside_run = {FRAME_rside_run_01, FRAME_rside_run_06, runt_frames_rside_run, NULL};
mmove_t	runt_move_rside_run = {FRAME_lside_run_01, FRAME_lside_run_06, runt_frames_rside_run, NULL};

mframe_t	runt_frames_crch_death1[] = 
{
	ai_move,	 -0.142, NULL,	// frame 0
	ai_move,	 -5.406, NULL,	// frame 1
	ai_move,	 -1.274, NULL,	// frame 2
	ai_move,	 -1.072, NULL,	// frame 3
	ai_move,	 -2.619, NULL,	// frame 4
	ai_move,	 -6.650, NULL,	// frame 5
	ai_move,	  1.475, NULL,	// frame 6
	ai_move,	  7.553, NULL,	// frame 7
	ai_move,	  3.779, NULL,	// frame 8
	ai_move,	  4.477, NULL,	// frame 9
	ai_move,	  5.449, NULL,	// frame 10
	ai_move,	  1.825, NULL,	// frame 11
	ai_move,	  1.503, NULL,	// frame 12
	ai_move,	  0.483, NULL,	// frame 13
	ai_move,	 -0.968, NULL,	// frame 14
	ai_move,	 -0.301, NULL,	// frame 15
	ai_move,	  0.195, NULL,	// frame 16
	ai_move,	 -0.106, NULL,	// frame 17
	ai_move,	 -0.053, NULL,	// frame 18
};
mmove_t	runt_move_crch_death1 = {FRAME_crch_death1_01, FRAME_crch_death1_19, runt_frames_crch_death1, AI_EndDeath};

mframe_t	runt_frames_crch_death2[] = 
{
	ai_move,	 -1.292, NULL,	// frame 0
	ai_move,	 -9.592, NULL,	// frame 1
	ai_move,	 -4.339, NULL,	// frame 2
	ai_move,	 14.878, NULL,	// frame 3
	ai_move,	 12.582, NULL,	// frame 4
	ai_move,	  6.198, NULL,	// frame 5
	ai_move,	  6.637, NULL,	// frame 6
	ai_move,	  3.702, NULL,	// frame 7
	ai_move,	 -1.876, NULL,	// frame 8
	ai_move,	 -1.002, NULL,	// frame 9
	ai_move,	  1.758, NULL,	// frame 10
};
mmove_t	runt_move_crch_death2 = {FRAME_crch_death2_01, FRAME_crch_death2_11, runt_frames_crch_death2, AI_EndDeath};

mframe_t	runt_frames_crch_death3[] = 
{
	ai_move,	 -0.655, NULL,	// frame 0
	ai_move,	 -4.884, NULL,	// frame 1
	ai_move,	-11.008, NULL,	// frame 2
	ai_move,	-11.476, NULL,	// frame 3
	ai_move,	 -8.028, NULL,	// frame 4
	ai_move,	 -7.586, NULL,	// frame 5
	ai_move,	-17.826, NULL,	// frame 6
	ai_move,	  4.965, NULL,	// frame 7
	ai_move,	  1.719, NULL,	// frame 8
	ai_move,	  0.809, NULL,	// frame 9
	ai_move,	 -0.198, NULL,	// frame 10
	ai_move,	  1.219, NULL,	// frame 11
	ai_move,	 -0.083, NULL,	// frame 12
	ai_move,	 -0.085, NULL,	// frame 13
	ai_move,	  0.088, NULL,	// frame 14
	ai_move,	  0.055, NULL,	// frame 15
	ai_move,	  0.046, NULL,	// frame 16
	ai_move,	  0.015, NULL,	// frame 17
};
mmove_t	runt_move_crch_death3 = {FRAME_crch_death3_01, FRAME_crch_death3_18, runt_frames_crch_death3, AI_EndDeath};

mframe_t	runt_frames_clmb_loop[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
	NULL,	  0.000, NULL,	// frame 9
};
mmove_t	runt_move_clmb_loop = {FRAME_clmb_loop_01, FRAME_clmb_loop_10, runt_frames_clmb_loop, AI_CheckStillClimbingLadder};

mframe_t	runt_frames_clmb_over[] = 
{
	ai_move,	 0.000, AI_CheckStillInair,	// frame 0
	ai_move,	 0.000, NULL,	// frame 1
	ai_move,	 0.000, NULL,	// frame 2
	ai_move,	 0.000, NULL,	// frame 3
	ai_move,	 0.000, NULL,	// frame 4
	ai_move,	 0.000, NULL,	// frame 5
	ai_move,	 0.000, NULL,	// frame 6
	ai_move,	 0.000, NULL,	// frame 7
	ai_move,	 0.000, NULL,	// frame 8
	ai_move,	 0.000, NULL,	// frame 9
	ai_move,	 0.000, NULL,	// frame 10
	ai_move,	 0.000, NULL,	// frame 11
};
mmove_t	runt_move_clmb_over = {FRAME_clmb_over_01, FRAME_clmb_over_12, runt_frames_clmb_over, AI_EndJump};

mframe_t	runt_frames_clmb_jmp[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
	NULL,	  0.000, NULL,	// frame 4
	NULL,	  0.000, NULL,	// frame 5
	NULL,	  0.000, NULL,	// frame 6
	NULL,	  0.000, NULL,	// frame 7
	NULL,	  0.000, NULL,	// frame 8
//	NULL,	  0.000, NULL,	// frame 9
//	NULL,	  0.000, NULL,	// frame 10
//	NULL,	  0.000, NULL,	// frame 11
//	NULL,	  0.000, NULL,	// frame 12
//	NULL,	  0.000, NULL,	// frame 13
//	NULL,	  0.000, NULL,	// frame 14
};
mmove_t	runt_move_clmb_jmp = {FRAME_clmb_over_01, FRAME_clmb_over_09, runt_frames_clmb_jmp, AI_EndJump};

mframe_t	runt_frames_evade_adjust[] = 
{
	ai_turn,	 -1.430, runt_evade_adjust,	// frame 9
	ai_turn,	 -5.835, runt_evade_adjust,	// frame 10
	ai_turn,	 -1.706, runt_evade_adjust,	// frame 11
	ai_turn,	 -0.040, runt_evade_adjust,	// frame 12
};
mmove_t	runt_move_evade_adjust = {FRAME_evade_05, FRAME_evade_08, runt_frames_evade_adjust, runt_evade_amb};

mframe_t	runt_frames_avoid_walk[] = 
{
	ai_turn,	 -1.594, NULL,	// frame 0
	ai_turn,	  9.027, NULL,	// frame 1
	ai_turn,	  0.580, NULL,	// frame 2
	ai_turn,	  7.894, NULL,	// frame 2
	ai_turn,	 -0.956, NULL,	// frame 3
	ai_turn,	 19.279, NULL,	// frame 4
	ai_turn,	 15.273, NULL,	// frame 5
};
mmove_t	runt_move_avoid_walk = {FRAME_walk_guns_dn_01, FRAME_walk_guns_dn_06, runt_frames_avoid_walk, AI_EndAttack};

mframe_t runt_frames_avoid_reverse_walk[] = 
{
	ai_turn, -6.953, NULL,	// frame 0
	ai_turn, -3.311, NULL,	// frame 1
	ai_turn, -5.149, NULL,	// frame 2
	ai_turn,-15.273, NULL,	// frame 3
	ai_turn,-19.279, NULL,	// frame 4
	ai_turn, -0.956, NULL,	// frame 5
};
mmove_t	runt_move_avoid_reverse_walk = {FRAME_walk_guns_dn_10, FRAME_walk_guns_dn_05, runt_frames_avoid_reverse_walk, AI_EndAttack};

mframe_t	runt_frames_crouch_avoid_walk[] = 
{
	ai_turn,	 4.227 , NULL,	// frame 0
	ai_turn,	 3.913 , NULL,	// frame 1
	ai_turn,	 4.576 , NULL,	// frame 2
	ai_turn,	 4.929 , NULL,	// frame 3
	ai_turn,	 4.588 , NULL,	// frame 4
	ai_turn,	 3.154 , NULL,	// frame 5
};
mmove_t	runt_move_crouch_avoid_walk = {FRAME_crouch_walk_01, FRAME_crouch_walk_06, runt_frames_crouch_avoid_walk, AI_EndAttack};

mframe_t	runt_frames_reverse_walk_shoot[] = 
{
//	ai_turn2,	 -0.298, NULL,	// frame 0
	ai_turn2,	 -3.334, NULL,	// frame 1
	ai_turn2,	 -3.541, NULL,	// frame 2
	ai_turn2,	 -8.010, NULL,	// frame 3
	ai_turn2,   -19.929, NULL,	// frame 4
	ai_turn2,	 -0.660, NULL,	// frame 5
	ai_turn2,	 -0.327, NULL,	// frame 6
	ai_turn2,	 -3.077, runt_right_fire,	// frame 7
	ai_turn2,	 -5.263, NULL,	// frame 8
	ai_turn2,	-10.442, NULL,	// frame 9
	ai_turn2,	 -1.378, runt_left_fire,	// frame 10
};
mmove_t	runt_move_reverse_walk_shoot = {FRAME_walk_shoot_10, FRAME_walk_shoot_01, runt_frames_reverse_walk_shoot, AI_EndAttack};
 
mframe_t	runt_frames_avoid_run[] = 
{
	ai_turn,12.722, NULL,	// frame 0
	ai_turn,19.632, NULL,	// frame 1
	ai_turn,22.735, NULL,	// frame 2
	ai_turn,20.400, NULL,	// frame 3
	ai_turn, 1.322, NULL,	// frame 4
	ai_turn,23.556, NULL,	// frame 5
};
mmove_t	runt_move_avoid_run = {FRAME_run_guns_dn_01, FRAME_run_guns_dn_06, runt_frames_avoid_run, AI_EndAttack};
 
mframe_t	runt_frames_avoid_reverse_run[] = 
{
	ai_turn,-23.556, NULL,	// frame 5
	ai_turn, -1.322, NULL,	// frame 4
	ai_turn,-20.400, NULL,	// frame 3
	ai_turn,-22.735, NULL,	// frame 2
	ai_turn,-19.632, NULL,	// frame 1
	ai_turn,-12.722, NULL,	// frame 0
};
mmove_t	runt_move_avoid_reverse_run = {FRAME_run_guns_dn_06, FRAME_run_guns_dn_01, runt_frames_avoid_reverse_run, AI_EndAttack};
 
mframe_t	runt_frames_stand_up[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
};
mmove_t	runt_move_stand_up = {FRAME_crch_knl_dn_06, FRAME_crch_knl_dn_03, runt_frames_stand_up, AI_EndAttack};

mframe_t	runt_frames_crouch_dn[] = 
{
	NULL,	  0.000, NULL,	// frame 0
	NULL,	  0.000, NULL,	// frame 1
	NULL,	  0.000, NULL,	// frame 2
	NULL,	  0.000, NULL,	// frame 3
};
mmove_t	runt_move_crouch_dn = {FRAME_crch_knl_dn_03, FRAME_crch_knl_dn_06, runt_frames_crouch_dn, AI_EndAttack};


mframe_t	runt_frames_evade_stand2[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
	ai_stand,	  0.000, NULL,	// frame 9
	ai_stand,	  0.000, NULL,	// frame 10
	ai_stand,	  0.000, NULL,	// frame 11
	ai_stand,	  0.000, NULL,	// frame 12
	ai_stand,	  0.000, NULL,	// frame 13
	ai_stand,	  0.000, NULL,	// frame 14
	ai_stand,	  0.000, NULL,	// frame 15
	ai_stand,	  0.000, NULL,	// frame 16
};
mmove_t	runt_move_evade_stand2 = {FRAME_melee_amb1_01, FRAME_melee_amb1_17, runt_frames_evade_stand2, runt_end_stand};

mframe_t	runt_frames_move_walk_dokey[] = 
{
	ai_runDOKEY,	  1.235, EP_ReachedDoKey,	// frame 0
	ai_runDOKEY,	  7.009, EP_ReachedDoKey,	// frame 1
	ai_runDOKEY,	  7.589, EP_ReachedDoKey,	// frame 2
	ai_runDOKEY,	 13.206, EP_ReachedDoKey,	// frame 3
	ai_runDOKEY,	  3.028, EP_ReachedDoKey,	// frame 4
	ai_runDOKEY,	  2.102, EP_ReachedDoKey,	// frame 5
	ai_runDOKEY,	 24.908, EP_ReachedDoKey,	// frame 6
	ai_runDOKEY,	 11.297, EP_ReachedDoKey,	// frame 7
	ai_runDOKEY,	 11.088, EP_ReachedDoKey,	// frame 8
	ai_runDOKEY,	  7.711, EP_ReachedDoKey,	// frame 9
};
mmove_t	runt_move_walk_dokey = {FRAME_walk_guns_dn_01, FRAME_walk_guns_dn_10, runt_frames_move_walk_dokey, EP_ReachedDoKey};

mframe_t	runt_frames_crch_dokey[] = 
{
	ai_stand,	  0.000, NULL,	// frame 0
	ai_stand,	  0.000, NULL,	// frame 1
	ai_stand,	  0.000, NULL,	// frame 2
	ai_stand,	  0.000, NULL,	// frame 3
	ai_stand,	  0.000, NULL,	// frame 4
	ai_stand,	  0.000, NULL,	// frame 5
	ai_stand,	  0.000, NULL,	// frame 6
	ai_stand,	  0.000, NULL,	// frame 7
	ai_stand,	  0.000, NULL,	// frame 8
	ai_stand,	  0.000, NULL,	// frame 9
	ai_stand,	  0.000, NULL,	// frame 10
	ai_stand,	  0.000, NULL,	// frame 11
	ai_stand,	  0.000, NULL,	// frame 12
	ai_stand,	  0.000, NULL,	// frame 13
	ai_stand,	  0.000, NULL,	// frame 14
	ai_stand,	  0.000, NULL,	// frame 15
	ai_stand,	  0.000, NULL,	// frame 16
	ai_stand,	  0.000, NULL,	// frame 17
	ai_stand,	  0.000, NULL,	// frame 18
	ai_stand,	  0.000, NULL,	// frame 19
	ai_stand,	  0.000, NULL,	// frame 20
	ai_stand,	  0.000, NULL,	// frame 21
	ai_stand,	  0.000, NULL,	// frame 22
	ai_stand,	  0.000, NULL,	// frame 23
	ai_stand,	  0.000, NULL,	// frame 24
	ai_stand,	  0.000, NULL,	// frame 25
	ai_stand,	  0.000, NULL,	// frame 26
};
mmove_t	runt_move_crch_dokey = {FRAME_crch_amb_sdt_01, FRAME_crch_amb_sdt_27, runt_frames_crch_dokey, EP_EndDoKey};
