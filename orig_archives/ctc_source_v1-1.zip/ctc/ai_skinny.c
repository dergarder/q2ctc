// ai_skinny.c

#include "g_local.h"
// #include "ai_skinny.h" // rename tris.h to this

#include "voice_punk.h"


// #include "ai_skinny_tables.h" // this is a clone of ai_punk_tables.h you need to fix this